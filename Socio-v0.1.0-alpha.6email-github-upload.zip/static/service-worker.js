const CACHE_NAME = "socio-static-v32";
const APP_SHELL = [
  "/static/site.css?v=alpha6-ui-pass2",
  "/static/theme.js",
  "/static/page-loading.js?v=alpha5-loading-screen1",
  "/static/local-times.js?v=alpha3-time1",
  "/static/member-gallery.js?v=alpha3-visits2",
  "/static/member-qr-scanner.js?v=alpha5-scanner-confirm3",
  "/static/member-notifications-live.js?v=alpha6-live-updates4",
  "/static/organization-notifications-live.js?v=alpha5-attendance-alerts1",
  "/static/organization-attendance.js?v=alpha6-live-attendance2",
  "/static/direct-messages-live.js?v=alpha6-live-messages1",
  "/static/notification-inbox-actions.js?v=alpha5-inbox-clear1",
  "/static/platform-activity-filter.js?v=alpha6-activity-filter1",
  "/static/member-visit-clock.js?v=alpha3-visits2",
  "/static/pwa.js",
  "/static/icons/socio-192.png",
  "/static/icons/socio-512.png",
  "/static/icons/apple-touch-icon.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((name) => name.startsWith("socio-static-") && name !== CACHE_NAME)
        .map((name) => caches.delete(name))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin
      || !url.pathname.startsWith("/static/")) {
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    try {
      const response = await fetch(request);
      if (response.ok && response.type === "basic") {
        cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      return cached || Response.error();
    }
  })());
});

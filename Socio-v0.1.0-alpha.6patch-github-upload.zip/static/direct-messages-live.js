(() => {
  if (!document.body.dataset.messageUser) return;
  const link = document.querySelector("[data-message-link]");
  const countBadge = document.querySelector("[data-message-count]");
  const region = document.querySelector("[data-notification-toast-region], [data-organization-toast-region], [data-message-toast-region]");
  const initialCursor = Number(document.body.dataset.messageLatest || 0);
  const cursorKey = `socio-message-cursor-${document.body.dataset.messageUser}`;
  let cursor = initialCursor;
  try {
    const saved = window.sessionStorage.getItem(cursorKey);
    const savedNumber = Number(saved);
    if (saved !== null && Number.isFinite(savedNumber) && savedNumber >= 0) {
      cursor = Math.min(savedNumber, initialCursor);
    } else {
      window.sessionStorage.setItem(cursorKey, String(initialCursor));
    }
  } catch (_) {
    // The live alerts can still work without session storage.
  }
  let polling = false;

  const setUnread = (count) => {
    const value = Math.max(0, Number(count) || 0);
    if (countBadge) {
      countBadge.textContent = value ? `(${value > 99 ? "99+" : value})` : "";
      countBadge.hidden = value === 0;
    }
    if (link) link.setAttribute("aria-label", value ? `Messages, ${value} unread` : "Messages");
  };

  const showToast = (message) => {
    if (!region) return;
    const card = document.createElement("article");
    card.className = "notification-toast message-notification-toast";
    card.setAttribute("role", "status");
    const heading = document.createElement("div");
    heading.className = "notification-toast-heading";
    const source = document.createElement("span");
    source.className = "eyebrow";
    source.textContent = `New message from ${message.sender || "Socio member"}`;
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "notification-toast-dismiss";
    dismiss.setAttribute("aria-label", "Dismiss message notification");
    dismiss.textContent = "×";
    dismiss.addEventListener("click", () => card.remove());
    heading.append(source, dismiss);
    const title = document.createElement("strong");
    title.textContent = message.subject || "New Socio message";
    const body = document.createElement("p");
    body.textContent = (message.body || "You received a new private message.").slice(0, 220);
    const open = document.createElement("a");
    open.href = "/messages";
    open.textContent = "Open messages →";
    card.append(heading, title, body, open);
    region.append(card);
    window.setTimeout(() => card.remove(), 18000);
  };

  const poll = async () => {
    if (polling || document.visibilityState === "hidden") return;
    polling = true;
    try {
      const response = await fetch(`/messages/live?after=${encodeURIComponent(cursor)}`, {
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) return;
      const payload = await response.json();
      for (const message of payload.messages || []) showToast(message);
      cursor = Math.max(cursor, Number(payload.latest_id) || cursor);
      try { window.sessionStorage.setItem(cursorKey, String(cursor)); } catch (_) {}
      setUnread(payload.unread_count);
    } catch (_) {
      // Retry automatically on the next interval.
    } finally {
      polling = false;
    }
  };

  poll();
  window.setInterval(poll, 5000);
  window.addEventListener("focus", poll);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") poll();
  });
})();

(() => {
  const search = document.querySelector("[data-member-search]");
  const select = document.querySelector("[data-member-select]");
  if (search && select) {
    const members = Array.from(select.options).slice(1).map((option) => ({
      option,
      text: `${option.textContent || ""} ${option.dataset.memberSearchValue || ""}`.toLocaleLowerCase()
    }));
    search.addEventListener("input", () => {
      const query = search.value.trim().toLocaleLowerCase();
      for (const member of members) member.option.hidden = Boolean(query) && !member.text.includes(query);
      if (select.selectedOptions[0]?.hidden) select.value = "";
    });
  }

  const table = document.querySelector("[data-live-attendance-table]");
  if (!table) return;
  const tbody = table.tBodies[0];
  const tableWrap = document.querySelector("[data-live-attendance-wrap]") || table.closest(".table-wrap");
  const empty = document.querySelector("[data-attendance-empty]");
  let serverClockOffset = 0;
  const pad = (value) => String(value).padStart(2, "0");
  const elapsedText = (seconds) => {
    const safe = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const remainder = safe % 60;
    return `${pad(hours)}:${pad(minutes)}:${pad(remainder)}`;
  };
  const compactDuration = (seconds) => {
    const safe = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const remainder = safe % 60;
    return hours ? `${hours}h ${pad(minutes)}m` : minutes ? `${minutes}m ${remainder}s` : `${remainder}s`;
  };
  const localDate = (iso) => {
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? "" :
      new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date);
  };
  const makeCell = (value, className) => {
    const cell = document.createElement("td");
    if (className) cell.className = className;
    cell.textContent = value || "";
    return cell;
  };
  const makeTime = (iso) => {
    const time = document.createElement("time");
    time.dateTime = iso;
    time.dataset.localTime = "";
    time.dataset.localFormat = "full";
    time.textContent = localDate(iso);
    return time;
  };
  const createRow = (visit) => {
    const row = document.createElement("tr");
    row.dataset.attendanceId = String(visit.id);
    const stateCell = document.createElement("td");
    const state = document.createElement("span");
    state.className = "attendance-state";
    state.dataset.attendanceState = "";
    stateCell.append(state);
    row.append(stateCell, makeCell(visit.member, ""), makeCell(visit.email, "staff-email"), makeCell(visit.tier, ""));
    const arrivalCell = document.createElement("td");
    arrivalCell.append(makeTime(visit.checked_in_at));
    row.append(arrivalCell);
    const leftCell = document.createElement("td");
    leftCell.dataset.attendanceLeft = "";
    row.append(leftCell);
    const durationCell = document.createElement("td");
    durationCell.dataset.attendanceDuration = "";
    row.append(durationCell, makeCell(visit.checked_in_by || "Member", ""));
    const method = visit.manual_entry ? "Manually recorded" :
      visit.method === "staff_scan" ? "Staff-assisted member pass" : "Member scanned organization QR";
    const methodCell = makeCell(method, "");
    methodCell.dataset.attendanceMethod = "";
    if (visit.staff_note) {
      methodCell.append(document.createElement("br"));
      const note = document.createElement("span");
      note.className = "field-hint";
      note.textContent = visit.staff_note;
      methodCell.append(note);
    }
    row.append(methodCell);
    return row;
  };
  const updateRow = (row, visit) => {
    const state = row.querySelector("[data-attendance-state]");
    const left = row.querySelector("[data-attendance-left]");
    const duration = row.querySelector("[data-attendance-duration]");
    if (!state || !left || !duration) return;
    state.replaceChildren();
    const dot = document.createElement("i");
    dot.className = "attendance-dot";
    dot.setAttribute("aria-hidden", "true");
    const departed = visit.checked_out_at ? Date.parse(visit.checked_out_at) : null;
    const checkedIn = departed === null || Number.isNaN(departed);
    const justDeparted = !checkedIn && Date.now() - departed < 5 * 60 * 1000;
    dot.classList.add(checkedIn ? "is-live" : justDeparted ? "is-just-checked-out" : "is-complete");
    state.append(dot, document.createTextNode(checkedIn ? " Checked in" : justDeparted ? " Checked out" : " Completed"));
    left.replaceChildren();
    if (checkedIn) {
      const live = document.createElement("span");
      live.className = "live-visit-label";
      live.textContent = "Still checked in";
      left.append(live);
      const timer = document.createElement("time");
      timer.className = "live-visit-timer";
      timer.dataset.liveVisitTimer = "";
      timer.dataset.startedAt = visit.checked_in_at;
      duration.replaceChildren(timer);
    } else {
      left.append(makeTime(visit.checked_out_at));
      const seconds = (departed - Date.parse(visit.checked_in_at)) / 1000;
      duration.textContent = compactDuration(seconds);
    }
  };
  const updateTimers = () => {
    document.querySelectorAll("[data-live-visit-timer][data-started-at]").forEach((timer) => {
      const started = Date.parse(timer.dataset.startedAt);
      if (Number.isNaN(started)) return;
      timer.textContent = elapsedText((Date.now() + serverClockOffset - started) / 1000);
    });
  };
  const pollAttendance = async () => {
    if (document.visibilityState === "hidden") return;
    try {
      const response = await fetch("/organization/attendance/live", {
        credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store"
      });
      if (!response.ok) return;
      const payload = await response.json();
      const serverNow = Date.parse(payload.server_now || "");
      if (!Number.isNaN(serverNow)) serverClockOffset = serverNow - Date.now();
      for (const visit of payload.visits || []) {
        let row = tbody.querySelector(`[data-attendance-id="${Number(visit.id)}"]`);
        if (!row) {
          row = createRow(visit);
          tbody.prepend(row);
        }
        updateRow(row, visit);
      }
      if ((payload.visits || []).length) {
        if (tableWrap) tableWrap.hidden = false;
        if (empty) empty.remove();
      }
      updateTimers();
    } catch (_) {
      // Current timers keep running; retry on the next interval.
    }
  };

  updateTimers();
  window.setInterval(updateTimers, 1000);
  pollAttendance();
  window.setInterval(pollAttendance, 5000);
  window.addEventListener("focus", pollAttendance);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") pollAttendance();
  });
})();

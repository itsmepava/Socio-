(() => {
  const search = document.querySelector("[data-activity-search]");
  const rows = [...document.querySelectorAll("[data-activity-item]")];
  const empty = document.querySelector("[data-activity-empty]");
  if (!search || !rows.length) return;

  search.addEventListener("input", () => {
    const query = search.value.trim().toLocaleLowerCase();
    let visible = 0;
    rows.forEach((row) => {
      const matches = !query || row.textContent.toLocaleLowerCase().includes(query);
      row.hidden = !matches;
      if (matches) visible += 1;
    });
    if (empty) empty.hidden = visible > 0;
  });
})();

# Socio v0.1.0-alpha.3

**Prerelease · Local and Codespaces testing build**

Alpha 3 adds a more complete club attendance flow and member expense rewards. It is intended for team review and demo use.

## Highlights

- **Club QR attendance:** Members scan an organization’s rotating QR code when they arrive and scan again when they leave. The organization attendance log records both timestamps and the visit duration.
- **Member Visit history:** A new member tab shows active visits and completed visits across clubs, including membership tier, visit date, arrival, departure, and total duration.
- **More reliable active timer:** The home screen timer starts from server-calculated elapsed time and continues with a monotonic browser clock, so phone clock or timezone differences do not distort the displayed duration.
- **Expense reward draws:** Organizations can create an optional expense reward draw with a prize, terms, deadline, and winner count. Members can opt a club expense into a draw. The organization reviews the receipt, closes entries, selects winners manually, and arranges the prize.
- **Member gallery:** Members can continue using the full gallery or compact tab view to find their clubs, membership passes, offers, events, and billing details.

## Demo limits

- Attendance needs camera permission and browser support. If the in-app camera scanner is unavailable, the phone camera can open the club QR link.
- Socio records visit times; organizations are responsible for displaying valid club QR codes and managing attendance policies.
- Expense proof review does not verify a bank transfer or issue reimbursement. Only accepted expense proofs qualify for reward draws.
- Reward draws are managed by the organization. Socio does not randomly select winners, verify prize fulfillment, or distribute prizes.
- Payments remain simulated. No real payment is collected or processed.
- This is a local/Codespaces demo, not a production consumer service. GCP hosting and native Android/iOS apps remain future work.

## Updating from Alpha 2

Back up your local demo database before starting Alpha 3. The app creates newly required tables and adds the attendance departure timestamp to an existing SQLite database during startup. Keep `.env`, SMTP credentials, database files, and real personal data out of the GitHub upload.

# Socio

Socio helps clubs and other member organizations manage the people who have already joined them. An organization records a member and sends a secure invitation; the member activates their account, completes their profile, consent, and any club onboarding form, then sees all their Socio clubs and receives club updates in one place.

This is an early alpha for the fresh Socio repository. It is a locally hosted web demo for team testing. The intended service has a GCP-hosted backend and organization web workspaces for managing rosters, staff roles, attendance, events, and offers. Members will use native Android and iOS apps for their clubs, notifications, and digital passes, distributed through Google Play and Apple’s App Store. Those deployment and mobile apps are future stages, not included in this alpha. All checkout flows are simulations; Socio does not process real payments.

## What this alpha includes

- Organization registration and platform-admin approval.
- Organization staff roles with scoped permissions.
- Member tiers for organizing existing club members.
- CSV roster import and individual member invitations.
- One-time invitation links; members can activate an existing account or create a password.
- Basic member profile, consent, and organization-specific onboarding questions.
- A private member gallery showing only the clubs the signed-in member belongs to.
- A member gallery switch between the full organization card grid and compact tabs that expand one selected club at a time; the choice is remembered in the browser.
- The phone preview loads the real Socio web pages at a phone-width viewport, including the responsive club gallery, profile, light/dark switch, membership actions, events, offers, and real QR pass pages.
- Signed-in members see their profile photo beside the welcome greeting; selecting it opens profile editing.
- Member search for organization staff, with onboarding responses visible to authorized staff.
- Member requests to upgrade or downgrade a club-defined membership tier, with optional context and organization approval.
- Every approved tier change proceeds through simulated checkout before it takes effect. Upgrade amounts are prorated; downgrades show zero additional amount due for the current paid period.
- Members can schedule or undo membership cancellation.
- Club-specific membership tier badges in the member gallery, with the organization’s highest priced tier marked as its top tier.
- A member billing area with membership payment history and photo-based bill or expense proof submissions for organization review. Proof acceptance is record review only; it does not verify or reimburse a payment.
- Organizations can publish optional reward draws. Members opt an eligible club expense into a draw; accepted proofs become entries and the organization manually selects and notifies winners. Socio does not run random selection or award prizes.
- A simulated tier-change checkout with sample card fields. Card data stays in the browser and is not sent to or stored by Socio.
- An organization transaction ledger showing its recorded payments and pending simulated checkouts.
- Member profile editing for display name, optional phone and gender details, and a resized profile picture.
- Members can use the in-app camera scanner to scan their organization’s QR on arrival and again on departure. Socio stores both timestamps and calculates the visit duration. The member home screen shows an ongoing visit and live elapsed time, while the **Visit history** tab lists completed visits across clubs with arrival, departure, and duration. The short-lived member-presented pass remains available for staff-assisted membership verification.
- A clickable Android/iPhone-style member app concept with a fixed-size phone screen, icon-grid club home, updates, passes, and profile screens. Signed-in members see their own memberships and notifications; signed-out visitors see clearly labeled sample content.
- In-app notification inbox plus optional email delivery for club updates.
- Events, posters, and offers that members can open for full details.
- SMTP email delivery when configured; local email preview is available for development.
- Existing club admission and offline fees remain managed by the organization; approved tier changes use the demo simulated checkout. No money is collected.

## Run locally on Windows

1. Install Python 3.12.
2. Extract this ZIP to a short folder path, for example `C:\Socio\alpha3`. Avoid deeply nested paths on Windows.
3. Open PowerShell in the extracted folder.
4. Run `python -m venv .venv`.
5. Run `Set-ExecutionPolicy -Scope Process Bypass` if PowerShell blocks the setup script.
6. Run `./start-local.ps1` and follow its prompts. The script installs requirements, prepares the local database, and starts Socio.
7. Open the local address printed in the terminal. Socio opens on a sign-in choice page for members, organization administrators, and platform staff. Keep that terminal window open while using the app.

During startup, choose **Y** for the sample Colombo Chess Club if you want demo fixtures. Then choose **Y** at the expanded sample prompt to add four more fictional clubs, member accounts, offers, events, notifications, and transaction examples. Sample fixtures are allowed only with local SQLite and a localhost or private Wi-Fi `PUBLIC_BASE_URL`; public tunnels and hosted services are rejected. It prints one randomly generated password for its sample members and sample organization admins; save that password from the terminal. Sample emails use the reserved `.test` domain. Do not use these fixtures on a public or production environment.

For manual setup, install `requirements.txt`, set a private `SECRET_KEY`, run the Flask database setup command documented in `start-local.ps1`, create the first platform administrator, then start the Flask app. Never use sample credentials for a public server.

To scan a local demo QR code from a separate phone, set `PUBLIC_BASE_URL` in `.env` to the host computer’s private Wi-Fi address, such as `http://192.168.1.20:5001`, then start with `./start-local.ps1 -BindAddress 0.0.0.0`. Keep both devices on the same trusted Wi-Fi network and allow Windows Firewall access only on the private network if prompted. Do not port-forward this local demo to the internet. The GCP-hosted production environment will use its HTTPS URL.

## SMTP email setup

SMTP is optional for local work. Without SMTP, development mode can display confirmation or invitation links in the server terminal. To send real email, create a local `.env` file from `.env.example` and set:

- `MAIL_SERVER`
- `MAIL_PORT`
- `MAIL_USERNAME`
- `MAIL_PASSWORD`
- `MAIL_FROM`
- `MAIL_USE_TLS`
- `MAIL_USE_SSL`
- `PUBLIC_BASE_URL`
- `DEV_EMAIL_PREVIEW=0`
- `SECRET_KEY`

For Gmail, use an App Password after enabling 2-Step Verification; do not use your normal Gmail password. Never commit `.env`, SMTP passwords, or secret keys to GitHub. On Codespaces or another host, configure these as environment secrets on that host and restart the app. In-app notifications are saved in Socio’s database and work independently of SMTP; SMTP sends an accompanying email when configured.

For GitHub Codespaces, follow [the Codespaces SMTP setup guide](docs/CODESPACES_SMTP_SETUP.md). It covers secure secret storage, the Codespaces HTTPS URL required for invitation links, and the local-only sample-data setup step.

## Main member flow

1. An organization administrator records someone already admitted by the club, individually or through the roster CSV.
2. Socio emails a one-time invitation link to that member’s address.
3. The member opens the link, signs into an existing Socio account or chooses a password, and completes profile, consent, and the organization’s onboarding form.
4. The member’s private Socio home shows the clubs they belong to, along with club events, offers, and notifications.
5. Organization staff search their own roster and send club-wide or member-specific updates. Updates appear in the Socio inbox and are also emailed when SMTP is configured and the member can receive mail.
6. Members can request an upgrade or downgrade for a club they belong to. The organization approves or declines the request; approved changes go through the simulated checkout. Admission criteria and initial fees are handled directly by the club.

## Product destination

The local web app is a temporary way to validate workflows with the team. The full product is planned as a GCP-hosted service: organizations use web workspaces for administration, while members use native Android and iOS apps. Before that launch, the backend, data storage, authentication, privacy, operational monitoring, and mobile app store requirements must be completed and reviewed.

## App and QR demo

Open **About Socio** in the footer and choose **Preview Socio on a phone**. It loads the real signed-in app inside a phone-sized frame, so organization QR check-in, membership passes, and other pages behave like the website itself. For attendance, the organization displays its rotating QR and members use Socio’s camera scanner on arrival and again on departure. Socio stores both timestamps and the visit duration. The separate short-lived member pass remains for staff-assisted membership verification; purchase or benefit redemption using that pass is future work.

For phone scanning on the same Wi-Fi, follow the local QR setup instructions above. This preview shows the responsive web app; it is not a native Android/iOS build or an app-store package.

## Notes for this alpha

Use test accounts and non-sensitive sample data. Invitation links are private credentials; share them only with the intended member. The app is not yet ready for public consumer use. Before GCP deployment, configure a supported database, persistent private file storage, backups, HTTPS, monitoring, account recovery, and complete an independent security and privacy review. Native Android and iOS apps for Google Play and Apple’s App Store are part of the intended consumer product and will be built after the core workflows are validated.

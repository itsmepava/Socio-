# Socio v0.1.0-alpha.3

**Prerelease · Local and Codespaces testing build**

Alpha 3 focuses on club attendance, visit history, and simpler membership management. It is intended for team review and demo use.

## Highlights

- **Club QR attendance:** Members scan an organization’s rotating QR code when they arrive and scan again when they leave. After check-in, Socio shows the current club session on the member home page. After checkout, a confirmation reports the visit duration and adds the visit to history.
- **Member visit history:** A member tab shows current and completed visits across clubs, including membership tier, visit date, arrival, departure, and total duration.
- **Accurate ongoing timer:** The member home page shows the club, tier, arrival time, and live elapsed time for an active visit. The timer continues from the server-calculated elapsed time, avoiding timezone and phone-clock drift.
- **Visit confirmation:** After checkout, members can dismiss the “thanks for coming” confirmation while keeping the visit in history.
- **Membership options:** Members can view simulated membership payment history, request approved tier changes, and schedule or undo cancellation. Tier changes still use simulated checkout; no real payment is processed.
- **Member gallery:** Members can switch between the organization card grid and compact tabs to find clubs, passes, offers, and events.

## Demo limits

- Attendance needs camera permission and browser support. If the in-app scanner is unavailable, the phone camera can open the club QR link.
- Organizations are responsible for displaying valid club QR codes and managing attendance policies.
- Payments remain simulated. No real payment is collected or processed.
- This is a local/Codespaces demo, not a production consumer service. GCP hosting and native Android/iOS apps remain future work.

## Updating from Alpha 2

Back up your local demo database before updating. The app applies required attendance schema updates to existing SQLite databases at startup. Keep `.env`, SMTP credentials, database files, and real personal data out of the GitHub upload.

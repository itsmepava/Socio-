# Socio v0.1.0-alpha.8

This prerelease lets organizations add their logo so members can recognize them in the gallery.

## Changes in this prerelease

- Added an organization-admin logo upload and remove control in the organization workspace.
- Displayed organization logos on the member gallery, home-page cards, member sign-in discovery cards, and public organization page. Organizations without a logo keep the initial-letter fallback.
- Accepts PNG, JPEG, and WebP input up to 1.5 MB and 20 megapixels, then normalizes it to a resized PNG without retaining source metadata.
- Stores normalized demo logos under the local instance directory using random server-generated names. Upload access is limited to organization administrators and scoped to their organization.
- Added a lightweight `/healthz` endpoint that reports whether the application can reach its database.
- Updated local demo dependencies and setup documentation.

## Scope

Uploaded logos are stored on the local app host. A hosted GCP deployment needs durable managed object storage and appropriate backup/lifecycle settings. Payments remain simulated.

See `docs/PRODUCTION_READINESS.md` for the current launch checklist and remaining operational work.

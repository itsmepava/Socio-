# Socio v0.1.0-alpha.19 — member signup, email retry, and layout fixes

## Changes

- Member accounts can now be created without choosing an organization. The organization selector is optional; members can browse and apply after they sign in.
- Existing SQLite databases are upgraded to allow organization-independent member accounts while preserving current users and their memberships.
- Resending an email confirmation now uses a short cooldown after a successful delivery. A failed SMTP attempt no longer invalidates the previous usable confirmation link, and failures are recorded in the server log without exposing credentials.
- Confirmation email is multipart text and HTML with clearer Socio branding and a direct confirmation button. This improves readability, but cannot guarantee inbox placement; Gmail and other providers control spam filtering.
- Added responsive text wrapping and minimum-width safeguards to keep long text inside panels, forms, and notices.

## SMTP and sender image

- Keep the authenticated Gmail address and the address in `MAIL_FROM` the same. Use a Google App Password for Gmail SMTP and keep it in a private environment variable or Codespaces secret.
- A sender profile image is managed in the Google Account for the Gmail address, not by Socio. Set the provided Socio avatar as that account's profile photo. Recipients may still see initials or a generic icon depending on their Gmail settings.
- A profile image does not improve spam classification by itself. Check the recipient's Spam folder and use **Not spam** for legitimate tests. Reliable consumer delivery will need a domain and properly configured email authentication with a transactional mail provider.

## Upload

- Extract this ZIP and upload its contents to the root of the Socio GitHub repository, replacing the older app files. Keep `app.py`, `requirements.txt`, `templates/`, and `static/` at the repository root.
- This ZIP contains only the alpha.19 release note; it excludes prior release notes, `.env`, databases, virtual environments, Git metadata, and old `dist` archives.
- After committing the files to a branch, open a fresh Codespace from that branch to try the release. Local `.env` settings do not transfer; add SMTP settings privately as Codespaces secrets and use the forwarded HTTPS URL for `PUBLIC_BASE_URL`.

Payments remain simulated. This is a development prerelease and is not ready for consumer production use.

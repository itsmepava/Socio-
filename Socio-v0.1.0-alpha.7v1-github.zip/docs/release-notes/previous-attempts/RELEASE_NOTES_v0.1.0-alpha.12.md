# Socio v0.1.0-alpha.12

## What's new

- Added step-by-step instructions for sharing the local demo through a Cloudflare Quick Tunnel, with an email allowlist for team access.
- Updated the Windows launcher to accept the generated public HTTPS URL, use secure session cookies, and build Socio account-confirmation links with that public URL.
- Kept the app and its database on the local computer. The Cloudflare URL is temporary and is intended for team review.

## Notes

- New member and organization registrations need SMTP configured to receive Socio confirmation emails. The seeded demo organization administrator and platform administrator can sign in without email delivery.
- Payments remain simulated. This prerelease is for controlled testing with synthetic data, not a consumer launch.
- No automated test suite was run for this packaging update.

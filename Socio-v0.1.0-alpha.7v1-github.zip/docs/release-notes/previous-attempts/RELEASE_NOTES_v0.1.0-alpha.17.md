# Socio v0.1.0-alpha.17 — connected brand and team preview

This manual update package contains the latest Socio source, including the account and team-role work from alpha.16.

## Changes in this package

- Applied the approved connected community mark alongside the `socio.` wordmark and orange terminal dot.
- Kept the existing light and dark themes, gradient styling, subtle motion, and reduced-motion support.
- Added the member account creation flow with organization selection, password confirmation, secure password hashing, and email confirmation.
- Added organization and platform staff invitations with scoped roles, single-use links, expiry, role changes, revocation, and server-side permission checks.
- Added platform email setup status and configurable SMTP delivery for email confirmations and team invitations. Gmail App Passwords can be used for controlled testing; store SMTP secrets outside the repository.
- Updated the member and organization portals, organization gallery, and local/Codespaces testing guidance.
- Removed Railway-specific setup from the current package. GitHub Codespaces is documented as a temporary team preview.

## Setup notes

- Extract this ZIP, then upload the files and folders inside it to the root of the GitHub repository, replacing the older app files. Keep `app.py`, `requirements.txt`, `templates/`, and `static/` at the repository root.
- Do not upload `.venv/`, `.git/`, `instance/`, database files, `.env`, or secrets. The ZIP omits older release-note files; this file is the release note for alpha.17.
- Follow `README.md` for Windows local setup, Gmail SMTP setup, and a temporary team preview through GitHub Codespaces.
- Payments remain simulated. Use synthetic data during review. Codespaces is not always-on hosting or durable production storage.

## Still needed before consumer use

Production database migrations, persistent managed database and image storage, tested backups and recovery, account recovery and administrator MFA, independent security/privacy review, and real payment-provider integration remain future work. Do not use this development preview to collect real payments or sensitive identity documents.

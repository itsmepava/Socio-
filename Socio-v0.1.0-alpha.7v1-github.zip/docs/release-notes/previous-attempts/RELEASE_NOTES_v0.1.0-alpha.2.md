# Socio v0.1.0-alpha.2

**Prerelease · Local testing build**

Alpha 2 continues the fresh Socio build with expanded member tools, simulated membership billing, and organization attendance tracking. It is intended for local and Codespaces testing and is not a production release.

## Highlights

- **Member accounts and profiles:** Members can activate an organization invitation, manage their profile details and photo, and view all their Socio-connected clubs in one account.
- **Club gallery:** Switch between organization cards and a compact tab view. Membership tier badges make each club’s current tier easier to spot.
- **Membership changes:** Request an upgrade or downgrade, optionally add a note, and wait for the organization to review it. Approved changes continue to simulated checkout.
- **Bills and expenses:** View Socio-recorded membership payments and submit a bill or expense with receipt evidence for organization review.
- **Optional expense reward draws:** Organizations can publish a prize, entry deadline, terms, and winner count. Members may opt a club expense into a draw; entries become eligible only after the organization accepts the expense proof. The organization closes entries, selects winners, and arranges prizes.
- **Organization workspace:** Configure monthly or yearly tier pricing, review member submissions, and see the club’s recorded transactions.
- **Arrival and departure QR:** Organizations display their rotating QR code. Members scan it in Socio when they arrive and again when they leave; the attendance log records both times and calculates visit duration. While checked in, the member home screen shows the active club, arrival time, and a live elapsed-time counter; after checkout it shows the latest visit duration. A short-lived member pass is retained for staff-assisted membership checks.
- **Phone-sized preview:** The preview uses the actual responsive Socio website, including its theme, gallery, profile, and membership features.
- **Expanded sample content:** Local demo setup can add fictional clubs, members, events, offers, notifications, and transaction examples.

## Demo limits

- Checkout is simulated; Socio does not collect or process money. Card fields are for the demo only and card details are not saved by Socio.
- Bill and expense evidence is reviewed by the organization. Acceptance records the review but does not verify a transfer or issue a reimbursement.
- The member-presented QR supports staff-assisted membership verification. Purchase or benefit redemption through that pass is future work.
- Reward draws are organization-run. Socio records opt-in entries and sends an in-app notice when an organization manually selects a winner; it does not randomize winners, verify prize fulfillment, or handle prize delivery.
- In-page camera scanning depends on browser support and camera permission. If scanning is unavailable, members can use their phone’s camera app to open the organization’s QR link.
- Sample data is fictional and is restricted to a local SQLite setup.
- This build is for team review. A GCP production service and native Android and iOS apps are future work.

## Upgrading from Alpha 1

Back up any existing local demo database before starting Alpha 2. On startup, the app creates missing tables and adds the required SQLite columns, including visit checkout timestamps. Do not upload `.env`, SMTP credentials, database files, or real payment-card details to GitHub.

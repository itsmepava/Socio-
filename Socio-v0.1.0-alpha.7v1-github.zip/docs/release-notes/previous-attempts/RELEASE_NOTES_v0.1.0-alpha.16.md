# Socio v0.1.0-alpha.16 — portals, sign-up, and team roles

## What's included

- Added a dedicated member sign-up page with organization selection, password confirmation, rate limiting, Argon2 password hashing, and email confirmation before sign-in.
- Clarified the separate member and organization portals, with a simpler product-led welcome page and direct sign-up actions.
- Added platform and organization team invitation pages. Owners can assign scoped roles, update roles, revoke pending invitations, and disable team access.
- Added one-time, hashed staff-invitation tokens that expire after 24 hours. New staff set their own password after opening the invite from their email.
- Enforced platform and organization permission scopes on protected server routes and hid dashboard sections outside the signed-in role's scope.
- Added a platform email setup page that reports configuration status without exposing secret values.
- Updated the local launcher to read an ignored `.env` file so local SMTP settings can be configured without committing credentials.
- Added password confirmation to member and organization account creation. Passwords remain at least 12 characters and are stored with Argon2.
- Refined the welcome copy, portal navigation, and gallery account actions.

## Role choices

- Platform: organization reviewer, finance reviewer, read-only.
- Organization: events and offers manager, membership manager, plans manager, finance manager, read-only.
- The original platform administrator and organization owner retain full access and can manage their team.

## Notes

- Email verification uses one-time links sent through the configured SMTP provider; local preview links print to the server terminal.
- Payments are simulated. This remains a development preview and needs a full security and operational review before consumer use.
- Do not commit `.env`, SMTP passwords, or secret keys.

# Previous-attempt release notes

These notes are kept for reference from earlier Socio repository attempts. They are not part of the current release sequence. The current project release files stay at the repository root; the What's new page reads the current and previous notes from both locations.

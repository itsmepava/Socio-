# Socio v0.1.0-alpha.15 — account signup and SMTP guidance

## Changes

- Added a clear member account creation entry point from member sign-in into the organization gallery and application flow.
- Clarified that a member account is created as part of applying for an organization plan.
- Added GitHub Codespaces SMTP secret setup instructions for email confirmation, including Gmail app-password guidance.

## Security and scope

- SMTP credentials belong in Codespaces secrets and must never be committed to the repository.
- Fine-grained platform and organization staff roles are not implemented in this release. Existing administrator roles retain their current boundaries.
- Payments remain simulated.

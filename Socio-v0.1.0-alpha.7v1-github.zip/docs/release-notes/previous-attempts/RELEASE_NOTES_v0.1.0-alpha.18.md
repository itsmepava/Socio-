# Socio v0.1.0-alpha.18 — email setup and UI refinement

## Changes

- Added Gmail SMTP setup guidance for local testing and a rate-limited test email action on the platform-admin Email setup page. Test messages go only to the signed-in admin account.
- Updated `.env.example` and the README with the Gmail App Password settings and local SMTP steps. SMTP secrets remain in the ignored local `.env` file or a private Codespaces secret.
- Replaced the temporary header/footer mark with the approved connected Socio logo and displayed it on the About page. The logo adapts to light and dark themes.
- Fixed approval and access notices that touched the bottom edge of organization settings panels.
- Smoothed button and card motion while honoring reduced-motion settings.
- Clarified that local SMTP settings are generic and no Railway service is required.

## Upload and run

- Extract this ZIP and upload the files and folders inside it to the root of your GitHub repository, replacing the older app files. Keep `app.py`, `requirements.txt`, `templates/`, and `static/` at the repository root.
- The ZIP contains only this release note. It does not include older release notes, `.env`, databases, virtual environments, Git metadata, or old `dist` archives.
- Follow `README.md` for Windows local testing, Gmail SMTP, and Codespaces setup. After configuring SMTP, sign in as a platform admin and use **Email setup → Send test email to my admin address**.
- Payments remain simulated. Use test data during review.

## Still needed before consumer use

Production database migrations, managed storage and backups, account recovery, administrator MFA, and independent security and privacy review remain future work. Real payments are not connected.

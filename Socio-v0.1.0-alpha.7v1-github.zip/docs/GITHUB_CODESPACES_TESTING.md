# GitHub Codespaces testing setup

This package is ready to copy into the root of the Socio GitHub repository and run in Codespaces. It contains application source and setup instructions, not a database or any private credentials. Keep the Codespace on a test branch and use fictional member data.

## 1. Add the package to the repository

1. Upload `Socio-v0.1.0-alpha.7-github-codespaces.zip` to the root of the Socio repository on the branch you want to test.
2. Commit the ZIP to that branch.
3. Create or open a Codespace on that same branch.
4. In its terminal, extract the source files into the repository root:

   ```bash
   unzip -o Socio-v0.1.0-alpha.7-github-codespaces.zip -d .
   ```

   The archive has the app files at its root, including `app.py`, `templates/`, and `static/`. If the ZIP has a different name in your repository, use that exact name in the command.

## 2. Add private Codespaces secrets

In the repository, open **Settings → Secrets and variables → Codespaces** and create these Codespaces secrets. If the repository uses personal Codespaces secrets instead, grant this repository access to them. Secrets configured only in another repository are not automatically available here.

| Secret | Example or value |
| --- | --- |
| `SECRET_KEY` | A unique random value. Generate one with `python -c "import secrets; print(secrets.token_urlsafe(48))"`. |
| `MAIL_SERVER` | `smtp.gmail.com` |
| `MAIL_PORT` | `587` |
| `MAIL_USERNAME` | Full address of the authorized Socio test sender. |
| `MAIL_PASSWORD` | Gmail App Password, without spaces. |
| `MAIL_FROM` | `Socio <sender@gmail.com>` using the same sender address. |
| `MAIL_USE_TLS` | `1` |
| `MAIL_USE_SSL` | `0` |

Use an App Password, not a normal Gmail password. Never put secrets in the ZIP, source files, or repository. `PUBLIC_BASE_URL`, `DEV_EMAIL_PREVIEW`, and `SESSION_COOKIE_SECURE` are set in the Codespace terminal because the forwarded URL is specific to that Codespace.

Optional background notifications need `WEB_PUSH_PUBLIC_KEY`, `WEB_PUSH_PRIVATE_KEY`, and `WEB_PUSH_CONTACT`. Leave those unset if you have not configured VAPID yet; the rest of the app still works.

After saving new secrets, stop and restart the Codespace so its terminal receives them.

## 3. Install and initialize the test app

Run these from the repository root. Do not reset an existing database if you need to keep its data.

```bash
python -m pip install -r requirements.txt
export PUBLIC_BASE_URL=http://127.0.0.1:5001
python -m flask --app 'app:create_app' init-db
python -m flask --app 'app:create_app' seed-demo
python -m flask --app 'app:create_app' seed-demo-expanded
python -m flask --app 'app:create_app' create-admin
```

`seed-demo` and `seed-demo-expanded` are optional, local SQLite demo-data commands. Run them only while `PUBLIC_BASE_URL` is localhost, before setting the public Codespaces address. The setup commands prompt for demo account details and passwords. Save those locally for your test session; do not share the platform-admin password.

If the database already exists, skip `init-db`. If demo fixtures already exist, skip the seed commands. If you already created the platform administrator, skip `create-admin`.

## 4. Start the app on the public Codespaces URL

In the same terminal, run:

```bash
export PUBLIC_BASE_URL="https://${CODESPACE_NAME}-5001.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN}"
export DEV_EMAIL_PREVIEW=0
export SESSION_COOKIE_SECURE=1
python -m flask --app 'app:create_app' run --host 0.0.0.0 --port 5001
```

In the **Ports** panel, set port `5001` to **Public** only if your team needs to open the preview without signing into GitHub. Share the HTTPS URL shown there. The URL changes when you create a different Codespace; update `PUBLIC_BASE_URL` and restart Socio. Keep the terminal running while you use the app.

## 5. Check SMTP

Register or invite a fictional test member, then confirm the email reaches the test inbox and that its link opens the current forwarded Socio URL. Check spam if needed. Socio’s in-app inbox is stored in the database; SMTP sends email alongside it when configured. If mail fails, confirm that the Codespace was restarted after adding the secrets and that `MAIL_FROM` matches the authenticated sender. Do not print secret values while troubleshooting.

Codespaces is a temporary test host. Use only synthetic data, and do not treat its SQLite database or uploaded files as durable production storage.

(() => {
  const panel = document.querySelector("[data-web-push-settings]");
  if (!panel) return;
  const status = panel.querySelector("[data-push-status]");
  const enableButton = panel.querySelector("[data-push-enable]");
  const disableButton = panel.querySelector("[data-push-disable]");
  const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  const say = (message, isError = false) => {
    if (!status) return;
    status.textContent = message;
    status.classList.toggle("is-error", isError);
  };
  const decodeKey = (encoded) => {
    const padding = "=".repeat((4 - encoded.length % 4) % 4);
    const base64 = (encoded + padding).replace(/-/g, "+").replace(/_/g, "/");
    return Uint8Array.from(atob(base64), (character) => character.charCodeAt(0));
  };
  const post = async (url, payload) => {
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRFToken": panel.dataset.csrf },
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error("Socio could not save this device setting. Please try again.");
  };
  if (!supported || !window.isSecureContext) {
    say("This browser needs HTTPS and notification support to enable background alerts.", true);
    if (enableButton) enableButton.disabled = true;
    if (disableButton) disableButton.disabled = true;
    return;
  }
  enableButton?.addEventListener("click", async () => {
    enableButton.disabled = true;
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") throw new Error("Notification permission was not granted. You can change it in browser settings.");
      const registration = await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: decodeKey(panel.dataset.publicKey),
      });
      await post(panel.dataset.subscribeUrl, subscription.toJSON());
      say("Background notifications are enabled on this device.");
    } catch (error) {
      say(error.message || "Could not enable notifications on this device.", true);
    } finally { enableButton.disabled = false; }
  });
  disableButton?.addEventListener("click", async () => {
    disableButton.disabled = true;
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) { say("Background notifications are already off on this device."); return; }
      await post(panel.dataset.unsubscribeUrl, { endpoint: subscription.endpoint });
      await subscription.unsubscribe();
      say("Background notifications were disabled on this device.");
    } catch (error) {
      say(error.message || "Could not disable notifications on this device.", true);
    } finally { disableButton.disabled = false; }
  });
})();

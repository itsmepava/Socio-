const CACHE_NAME = "socio-static-v37";
const APP_SHELL = [
  "/static/site.css?v=alpha7-push3",
  "/static/theme.js",
  "/static/page-loading.js?v=alpha5-loading-screen1",
  "/static/local-times.js?v=alpha3-time1",
  "/static/member-gallery.js?v=alpha3-visits2",
  "/static/member-qr-scanner.js?v=alpha7-qr-purpose1",
  "/static/notification-bell.js?v=alpha6-unified-notifications1",
  "/static/member-notifications-live.js?v=alpha6-unified-notifications1",
  "/static/organization-notifications-live.js?v=alpha6-unified-notifications1",
  "/static/organization-attendance.js?v=alpha6-live-attendance3",
  "/static/direct-messages-live.js?v=alpha6-unified-notifications1",
  "/static/support-notifications-live.js?v=alpha7-support-live1",
  "/static/web-push-settings.js?v=alpha7-push1",
  "/static/notification-inbox-actions.js?v=alpha5-inbox-clear1",
  "/static/platform-activity-filter.js?v=alpha6-activity-filter1",
  "/static/member-visit-clock.js?v=alpha3-visits2",
  "/static/pwa.js",
  "/static/icons/socio-192.png",
  "/static/icons/socio-512.png",
  "/static/icons/apple-touch-icon.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((name) => name.startsWith("socio-static-") && name !== CACHE_NAME)
        .map((name) => caches.delete(name))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener("push", (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch (_) {}
  const title = String(payload.title || "Socio update").slice(0, 120);
  const body = String(payload.body || "You have a new update.").slice(0, 240);
  const target = typeof payload.url === "string" && payload.url.startsWith("/")
    && !payload.url.startsWith("//") ? payload.url : "/welcome";
  event.waitUntil(self.registration.showNotification(title, {
    body,
    icon: "/static/icons/socio-192.png",
    badge: "/static/icons/socio-192.png",
    data: { url: target },
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = event.notification.data && event.notification.data.url;
  const url = typeof target === "string" && target.startsWith("/") && !target.startsWith("//")
    ? new URL(target, self.location.origin).href : new URL("/welcome", self.location.origin).href;
  event.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then((windows) => {
    for (const client of windows) {
      if (new URL(client.url).origin === self.location.origin && "focus" in client) {
        client.navigate(url);
        return client.focus();
      }
    }
    return clients.openWindow(url);
  }));
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin
      || !url.pathname.startsWith("/static/")) {
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    try {
      const response = await fetch(request);
      if (response.ok && response.type === "basic") {
        cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      return cached || Response.error();
    }
  })());
});

(() => {
  if (!document.body.dataset.messageUser) return;
  const region = document.querySelector("[data-support-toast-region]");
  const userId = document.body.dataset.messageUser;
  let cursor = Number(document.body.dataset.supportLatest || 0);
  let polling = false;
  const updateCount = (count) => {
    const value = Math.max(0, Number(count) || 0);
    document.body.dataset.supportUnread = String(value);
    const menuCount = document.querySelector("[data-support-menu-count]");
    if (menuCount) menuCount.textContent = value > 99 ? "99+" : String(value);
    window.dispatchEvent(new CustomEvent("socio:notification-count", {
      detail: { source: "support", count: value },
    }));
  };
  const showToast = (message) => {
    if (!region) return;
    const card = document.createElement("article");
    card.className = "notification-toast support-notification-toast";
    card.setAttribute("role", "status");
    const heading = document.createElement("div");
    heading.className = "notification-toast-heading";
    const label = document.createElement("span");
    label.className = "eyebrow";
    label.textContent = "Socio support";
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "notification-toast-dismiss";
    dismiss.setAttribute("aria-label", "Dismiss support notification");
    dismiss.textContent = "×";
    dismiss.addEventListener("click", () => card.remove());
    heading.append(label, dismiss);
    const title = document.createElement("strong");
    title.textContent = message.subject || "Support ticket reply";
    const body = document.createElement("p");
    body.textContent = `${message.sender || "Support team"}: ${(message.body || "A support ticket was updated.").slice(0, 200)}`;
    const link = document.createElement("a");
    link.href = `/support/tickets/${encodeURIComponent(message.ticket_id)}`;
    link.textContent = "Open support ticket →";
    card.append(heading, title, body, link);
    region.append(card);
    window.setTimeout(() => card.remove(), 18000);
  };
  const poll = async () => {
    if (polling || document.visibilityState === "hidden") return;
    polling = true;
    try {
      const response = await fetch(`/support/live?after=${encodeURIComponent(cursor)}`, {
        credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store",
      });
      if (!response.ok) return;
      const payload = await response.json();
      for (const message of payload.messages || []) showToast(message);
      cursor = Math.max(cursor, Number(payload.latest_id) || cursor);
      updateCount(payload.unread_count);
    } catch (_) {
      // Retry on the next poll.
    } finally { polling = false; }
  };
  if (userId) {
    poll();
    window.setInterval(poll, 20000);
    window.addEventListener("focus", poll);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") poll();
    });
  }
})();

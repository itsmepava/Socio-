# Socio v0.1.0-alpha.7

Alpha 7 adds organization-managed facility bookings, a QR flow for booking payments and attendance, and a support-ticket workspace. Browser push is available as an optional background alert channel.

## Included

- Organizations can publish bookable facilities with schedules, slot lengths, capacity, guest limits, membership-tier access, and an optional booking fee.
- Members can request a facility booking for themselves and listed guests. The organization has 24 hours from submission to approve or decline; members can cancel a pending request.
- Members can cancel eligible approved bookings. Organizations can configure optional late-cancellation and no-show policy fees; booking payments, fees, and refunds are clearly marked simulated and do not move money.
- The club QR asks members to choose **Attendance** or **Facility booking**. For bookings, members see the matching booking details, explicitly confirm a simulated QR payment when needed, and separately confirm arrival or departure. Scanning alone never records payment or attendance.
- Members and organizations can follow booking status, payment state, check-in/out, and policy records from their booking and finance pages.
- Members and organization staff can open support tickets, exchange replies, and see ticket updates. Platform owners can assign a scoped **Support agent** role; support agents are directed to the ticket workspace and cannot open the general private-message directory.
- Optional browser push can deliver club updates, messages, booking changes, and support replies when the user has enabled alerts on that device and the app is configured with HTTPS and VAPID keys.
- Booking times are normalized to UTC for consistent handling across local SQLite and timezone-aware databases. Cancellation confirmation refreshes if the displayed fee or refund changes before submission.
- The About page no longer includes the phone mockup; the responsive member web app remains available for local testing.

## Testing notes

- All payment actions and policy ledger entries are simulations. No real payment card data is requested or stored.
- Browser push is optional. Without VAPID configuration and device permission, in-app updates and existing email behavior continue to work.
- This remains a local alpha demo. Use synthetic data; do not use it for real member records or production payments.

## Release tag

`v0.1.0-alpha.7`

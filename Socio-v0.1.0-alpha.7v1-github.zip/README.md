# Socio

Socio helps clubs and other member organizations manage the people who have already joined them. An organization records a member and sends a secure invitation; the member activates their account, completes their profile, consent, and any club onboarding form, then sees all their Socio clubs and receives club updates in one place.

This is an early alpha for the fresh Socio repository. It is a locally hosted web demo for team testing. The intended service has a GCP-hosted backend and organization web workspaces for managing rosters, staff roles, attendance, events, and offers. Members will use native Android and iOS apps for their clubs, notifications, and digital passes, distributed through Google Play and Apple’s App Store. Those deployment and mobile apps are future stages, not included in this alpha. All checkout flows are simulations; Socio does not process real payments.

## What this alpha includes

- Organization registration and platform-admin approval.
- Organization staff roles with scoped permissions.
- Member tiers for organizing existing club members.
- CSV roster import and individual member invitations.
- One-time invitation links; members can activate an existing account or create a password.
- Basic member profile, consent, and organization-specific onboarding questions.
- A private member gallery showing only the clubs the signed-in member belongs to.
- A member gallery switch between the full organization card grid and compact tabs that expand one selected club at a time; the choice is remembered in the browser.
- Signed-in members see their profile photo beside the welcome greeting; selecting it opens profile editing.
- Mobile web pages use a collapsible, touch-friendly navigation bar and single-column member cards. Signed-in users can choose Automatic, Mobile, or Desktop display under Settings; the preference is saved per browser, and phone screens remain responsive.
- A branded Socio loading screen appears on in-app navigation and valid form submissions when a page takes longer to load. It avoids flashing on fast local requests and respects reduced-motion settings.
- Club update cards have improved mobile spacing, readable text wrapping, and status badges that stay on one line in both light and dark themes.
- Member search for organization staff, with onboarding responses visible to authorized staff.
- The organization member directory shows real join dates and each member’s latest five Socio QR visits, including visit duration, alongside the searchable membership record.
- Member requests to upgrade or downgrade a club-defined membership tier, with optional context and organization approval.
- Every approved tier change proceeds through simulated checkout before it takes effect. Upgrade amounts are prorated; downgrades show zero additional amount due for the current paid period.
- Members can schedule or undo membership cancellation.
- Club-specific membership tier badges in the member gallery, with the organization’s highest priced tier marked as its top tier.
- A member payment-history page for simulated membership payments and offline payment records. It does not collect or store real card details.
- A simulated tier-change checkout with sample card fields. Card data stays in the browser and is not sent to or stored by Socio.
- An organization transaction ledger showing its recorded payments and pending simulated checkouts.
- Member profile editing for display name, optional phone and gender details, and a resized profile picture.
- Members can use the in-app camera scanner to scan their organization’s QR on arrival and again on departure. After check-in, the member home page shows a prominent **Current ongoing session** card with the club, tier, arrival time, and live elapsed timer. After checkout, Socio thanks the member, reports the duration, and confirms the visit was saved. The **Visit history** tab lists completed visits across clubs with arrival, departure, and duration. Visit timestamps are stored in UTC and shown in the viewer’s local timezone. The short-lived member-presented pass remains available for staff-assisted membership verification.
- In-app notification inbox plus optional email delivery for club updates.
- Event posters are included in member event alerts and SMTP email when provided. Organizations can also attach an optional image to a club update; it appears in the inbox and live popup and is embedded in email when SMTP is configured.
- Members can choose Socio inbox, pop-up, and email updates separately for each organization. A small bell shows unread updates, and a discreet live popup appears for new updates while Socio is open. Pop-ups can be disabled independently.
- Each organization can enable or disable Socio QR attendance from its dashboard. Existing organizations keep the feature enabled during upgrade; organizations that disable it can use their own check-in process.
- Organization-managed facility reservations support schedules, capacity, guest names, membership-tier eligibility, approval, and a 24-hour decision window. Members can cancel pending or approved bookings.
- Facility booking fees are optional simulated QR payments. Scanning alone never charges or records attendance: the member reviews the booking and amount, then explicitly confirms each payment or attendance action. Organizations can leave late-cancellation and no-show fees at zero; any enabled policy fees and simulated refunds are shown as demo ledger records.
- Support tickets let members and organization staff contact Socio and follow replies. Platform admins can invite support agents with access limited to the support workspace. Replies appear in the notification bell and live in-app alerts.
- Optional browser push can show selected updates on opted-in devices while Socio is closed, when HTTPS and VAPID keys are configured. In-app and email notifications remain available without push.
- Organization staff with member-management access can manually check active roster members in and out, with an optional reference or note. Arrival, departure, and manual attendance alerts appear in the staff notification inbox and as live popups while they are signed in.
- The organization attendance view refreshes visit state in the background, shows a seconds-updating elapsed timer for checked-in members, and freezes it at the recorded checkout time.
- Organizations can add up to ten optional or required questions to the staff attendance form. Answers are saved with the visit and shown in the attendance history.
- Members, organization staff, and platform staff can exchange private in-app messages and replies. New messages show a live on-screen alert and update the unread count while the recipient is using Socio. SMTP sends an email alert when configured and the recipient email is verified; messages remain in Socio if email is unavailable.
- The notification bell combines unread club updates, attendance alerts, and private messages in a small menu linking to the matching inbox.
- The clickable release version opens a side-by-side comparison of the current and previous release notes. `VERSION` selects the current release; include its release notes and the immediately previous release notes in each release package.
- Platform admins with reports access can search member records by name, email, organization, or membership tier and open a private support message.
- Platform activity can be collapsed and filtered with a search field. The About page no longer includes the phone mockup preview; the actual web app remains responsive on phones.
- Events, posters, and offers that members can open for full details.
- SMTP email delivery when configured; local email preview is available for development.
- Existing club admission and offline fees remain managed by the organization; approved tier changes use the demo simulated checkout. No money is collected.

## Run locally on Windows

1. Install Python 3.12.
2. Extract this ZIP to a short folder path, for example `C:\Socio\alpha6`. Avoid deeply nested paths on Windows.
3. Open PowerShell in the extracted folder.
4. Run `python -m venv .venv`.
5. Run `Set-ExecutionPolicy -Scope Process Bypass` if PowerShell blocks the setup script.
6. Run `./start-local.ps1` and follow its prompts. The script installs requirements, prepares the local database, and starts Socio.
7. Open the local address printed in the terminal. Socio opens on a sign-in choice page for members, organization administrators, and platform staff. Keep that terminal window open while using the app.

During startup, choose **Y** for the sample Colombo Chess Club if you want demo fixtures. Then choose **Y** at the expanded sample prompt to add four more fictional clubs, member accounts, offers, events, notifications, and transaction examples. Sample fixtures are allowed only with local SQLite and a localhost or private Wi-Fi `PUBLIC_BASE_URL`; public tunnels and hosted services are rejected. It prints one randomly generated password for its sample members and sample organization admins; save that password from the terminal. Sample emails use the reserved `.test` domain. Do not use these fixtures on a public or production environment.

For manual setup, install `requirements.txt`, set a private `SECRET_KEY`, run the Flask database setup command documented in `start-local.ps1`, create the first platform administrator, then start the Flask app. Never use sample credentials for a public server.

To scan a local demo QR code from a separate phone, set `PUBLIC_BASE_URL` in `.env` to the host computer’s private Wi-Fi address, such as `http://192.168.1.20:5001`, then start with `./start-local.ps1 -BindAddress 0.0.0.0`. Keep both devices on the same trusted Wi-Fi network and allow Windows Firewall access only on the private network if prompted. Do not port-forward this local demo to the internet. When the setting still points to localhost, generated QR links automatically use the active private Wi-Fi, Codespaces, or Cloudflare preview host. The GCP-hosted production environment will use its HTTPS URL.

## SMTP email setup

SMTP remains part of Socio and is optional for local work. Without SMTP, development mode can display confirmation or invitation links in the server terminal. In-app private messages and notifications continue to work without SMTP; when it is configured, Socio also emails account confirmations, invitations, club updates, and private-message alerts (for recipients with verified email). To send real email, create a local `.env` file from `.env.example` and set:

- `MAIL_SERVER`
- `MAIL_PORT`
- `MAIL_USERNAME`
- `MAIL_PASSWORD`
- `MAIL_FROM`
- `MAIL_USE_TLS`
- `MAIL_USE_SSL`
- `PUBLIC_BASE_URL`
- `DEV_EMAIL_PREVIEW=0`
- `SECRET_KEY`

For Gmail, use an App Password after enabling 2-Step Verification; do not use your normal Gmail password. Never commit `.env`, SMTP passwords, or secret keys to GitHub. On Codespaces or another host, configure these as environment secrets on that host and restart the app. In-app notifications are saved in Socio’s database and work independently of SMTP; SMTP sends an accompanying email when configured.

For GitHub Codespaces, follow [the Codespaces testing setup](docs/GITHUB_CODESPACES_TESTING.md) to extract the upload ZIP, add SMTP secrets, initialize demo data, and run Socio on the forwarded HTTPS URL. The [SMTP reference](docs/CODESPACES_SMTP_SETUP.md) has additional provider details.

## Main member flow

1. An organization administrator records someone already admitted by the club, individually or through the roster CSV.
2. Socio emails a one-time invitation link to that member’s address.
3. The member opens the link, signs into an existing Socio account or chooses a password, and completes profile, consent, and the organization’s onboarding form.
4. The member’s private Socio home shows the clubs they belong to, along with club events, offers, and notifications.
5. Organization staff search their own roster and send club-wide or member-specific updates. Updates appear in the Socio inbox and are also emailed when SMTP is configured and the member can receive mail.
6. Members can request an upgrade or downgrade for a club they belong to. The organization approves or declines the request; approved changes go through the simulated checkout. Admission criteria and initial fees are handled directly by the club.

## Product destination

The local web app is a temporary way to validate workflows with the team. The full product is planned as a GCP-hosted service: organizations use web workspaces for administration, while members use native Android and iOS apps. Before that launch, the backend, data storage, authentication, privacy, operational monitoring, and mobile app store requirements must be completed and reviewed.

## App and QR demo

The current alpha is a responsive web app; there is no separate phone mockup. The member QR scanner offers separate Club attendance and Facility booking purposes. The organization displays its rotating QR; members scan it, review the applicable booking or visit, and confirm the next action. Payments require an extra explicit confirmation and remain simulated.

For phone scanning on the same Wi-Fi, follow the local QR setup instructions above. Native Android/iOS apps and app-store packages are planned for a later stage.

## Optional browser push setup

Browser push requires HTTPS, the `pywebpush` package from `requirements.txt`, and a VAPID key pair. Generate keys from the virtual environment with `.venv\\Scripts\\vapid.exe --gen` on Windows, or `vapid --gen` on other systems. Keep `private_key.pem` outside Git; PEM files are ignored. Use the command’s `--applicationServerKey` output as `WEB_PUSH_PUBLIC_KEY`. Set `WEB_PUSH_PRIVATE_KEY` to the private PEM file path locally, or paste the PEM value into the host’s secret setting. Set `WEB_PUSH_CONTACT` to an operations contact such as `mailto:team@example.com`. Each user enables push for their device in **Settings → Background notifications**. Alerts include new messages, support replies, booking decisions, and club updates. Browser support and user permission are required.

## Notes for this alpha

Use test accounts and non-sensitive sample data. Invitation links are private credentials; share them only with the intended member. The app is not yet ready for public consumer use. Before GCP deployment, configure a supported database, persistent private file storage, backups, HTTPS, monitoring, account recovery, and complete an independent security and privacy review. Native Android and iOS apps for Google Play and Apple’s App Store are part of the intended consumer product and will be built after the core workflows are validated.

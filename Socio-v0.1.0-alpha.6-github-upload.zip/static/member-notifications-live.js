(() => {
  const bell = document.querySelector("[data-notification-bell]");
  const badge = document.querySelector("[data-notification-count]");
  const region = document.querySelector("[data-notification-toast-region]");
  if (!bell || !badge || !region) return;

  let cursor = Number(document.body.dataset.notificationLatest || 0);
  let polling = false;

  const updateUnread = (count) => {
    const value = Math.max(0, Number(count) || 0);
    badge.textContent = value > 99 ? "99+" : String(value);
    badge.hidden = value === 0;
    bell.setAttribute("aria-label", value ? `Club updates, ${value} unread` : "Club updates");
  };

  const showToast = (notification) => {
    const card = document.createElement("article");
    card.className = "notification-toast";
    card.setAttribute("role", "status");
    const heading = document.createElement("div");
    heading.className = "notification-toast-heading";
    const source = document.createElement("span");
    source.className = "eyebrow";
    source.textContent = notification.organization || "Club update";
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "notification-toast-dismiss";
    dismiss.setAttribute("aria-label", "Dismiss club update notification");
    dismiss.textContent = "×";
    dismiss.addEventListener("click", () => card.remove());
    heading.append(source, dismiss);

    const title = document.createElement("strong");
    title.textContent = notification.title || "New club update";
    const body = document.createElement("p");
    body.textContent = notification.body || "A club has shared an update with you.";
    const link = document.createElement("a");
    link.href = "/member/notifications";
    link.textContent = "Open updates →";
    link.addEventListener("click", () => card.remove());
    card.append(heading, title, body, link);
    region.append(card);
    window.setTimeout(() => card.remove(), 15000);
  };

  const poll = async () => {
    if (polling || document.visibilityState === "hidden") return;
    polling = true;
    try {
      const response = await fetch(`/member/notifications/live?after=${encodeURIComponent(cursor)}`, {
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) return;
      const payload = await response.json();
      cursor = Math.max(cursor, Number(payload.latest_id) || cursor);
      updateUnread(payload.unread_count);
      (payload.notifications || []).filter((notification) => notification.popup_enabled !== false)
        .slice(0, 3).forEach(showToast);
    } catch (_) {
      // A temporary network interruption should not interrupt the member's current page.
    } finally {
      polling = false;
    }
  };

  // Fetch once when the page opens, then poll often enough that an active
  // member sees club updates promptly. This remains below the route's limit.
  poll();
  window.setInterval(poll, 15000);
  window.addEventListener("focus", poll);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") poll();
  });
})();

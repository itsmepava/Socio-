(() => {
  const recordType = document.querySelector('[data-billing-record-type]');
  const raffleSelect = document.querySelector('[data-raffle-select]');
  const hint = document.querySelector('[data-raffle-hint]');
  if (!recordType || !raffleSelect) return;
  const update = () => {
    const isExpense = recordType.value === 'Club expense';
    raffleSelect.disabled = !isExpense;
    if (!isExpense) raffleSelect.value = '';
    if (hint) hint.textContent = isExpense
      ? 'Choosing a draw opts this expense into its entry list. Your proof is shared with the organization for review; an accepted proof is eligible under the draw terms.'
      : 'Choose “Club expense” above to enter an open draw.';
  };
  recordType.addEventListener('change', update);
  update();
})();

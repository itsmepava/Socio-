(() => {
  const video = document.querySelector('[data-qr-video]');
  const startButton = document.querySelector('[data-qr-start]');
  const stopButton = document.querySelector('[data-qr-stop]');
  const status = document.querySelector('[data-qr-status]');
  const placeholder = document.querySelector('[data-qr-placeholder]');
  const fallback = document.querySelector('[data-qr-fallback]');
  if (!video || !startButton || !stopButton || !status) return;

  let stream;
  let scanning = false;
  let detector;

  const setStatus = (message) => { status.textContent = message; };
  const stop = () => {
    scanning = false;
    if (stream) stream.getTracks().forEach((track) => track.stop());
    stream = undefined;
    video.srcObject = null;
    startButton.disabled = false;
    stopButton.disabled = true;
    placeholder.hidden = false;
  };

  const findSocioCheckin = (rawValue) => {
    try {
      const url = new URL(rawValue, window.location.origin);
      if (url.origin !== window.location.origin) return null;
      const match = url.pathname.match(/^\/check-in\/club\/([A-Za-z0-9_-]{20,160})\/?$/);
      return match ? `/check-in/club/${match[1]}` : null;
    } catch (_) {
      return null;
    }
  };

  const scanFrame = async () => {
    if (!scanning) return;
    try {
      const codes = await detector.detect(video);
      const target = codes.map((code) => findSocioCheckin(code.rawValue)).find(Boolean);
      if (target) {
        scanning = false;
        setStatus('Organization code found. Opening Socio…');
        stop();
        window.location.assign(target);
        return;
      }
    } catch (_) {
      // Frames can be temporarily unreadable while the camera adjusts.
    }
    if (scanning) window.requestAnimationFrame(scanFrame);
  };

  startButton.addEventListener('click', async () => {
    fallback.hidden = true;
    if (!('BarcodeDetector' in window) || !navigator.mediaDevices?.getUserMedia) {
      setStatus('This browser does not provide in-page QR scanning. Use your phone camera app to scan the organization code.');
      fallback.hidden = false;
      return;
    }
    try {
      detector = new window.BarcodeDetector({ formats: ['qr_code'] });
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      video.srcObject = stream;
      await video.play();
      scanning = true;
      startButton.disabled = true;
      stopButton.disabled = false;
      placeholder.hidden = true;
      setStatus('Point your camera at the organization’s QR code.');
      window.requestAnimationFrame(scanFrame);
    } catch (_) {
      stop();
      setStatus('Camera access was unavailable. Allow camera permission, then try again.');
      fallback.hidden = true;
    }
  });

  stopButton.addEventListener('click', () => {
    stop();
    setStatus('The camera is off.');
  });
  window.addEventListener('pagehide', stop);
})();

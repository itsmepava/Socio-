# Socio v0.1.0-alpha.5

**Prerelease · Local and Codespaces testing build**

Alpha 5 makes member communications and organization attendance more configurable, with clearer member onboarding and richer organization member records.

## Changes in Alpha 5

- Added a three-step guide to member invitation activation: profile, organization form, and consent/access.
- Added each member’s actual join date and recent Socio QR visit history to the organization member directory. Existing member search, tier, status, consent, and onboarding details remain available to staff with member-management access.
- Added per-organization member preferences for the Socio inbox, pop-up alerts, and email updates. Members can disable pop-ups while keeping updates in their inbox or email. Email delivery requires a confirmed address and SMTP configuration.
- Added a compact notification bell with unread count and live update popups. While Socio is open, it checks for new club updates every 30 seconds; pop-ups respect each member’s per-club setting.
- Added a QR attendance toggle to the organization dashboard. Organizations can switch off Socio QR check-in and continue using their own attendance process. Turning it off revokes active QR codes and blocks attendance records from those codes.
- Added staff-assisted manual attendance. Authorized organization staff can find an active roster member, record arrival or departure, and optionally add a reference or note. This works even when the organization disables Socio QR check-in.
- Added organization attendance alerts for member QR check-ins, checkouts, and staff-recorded visits. Authorized staff see an unread bell count, live popups while signed in, and a persistent alert inbox.
- Added visit status indicators to the attendance list: pulsing green for current visits, red for a recent checkout, and gray for completed visits.
- Fixed QR origin matching for local Wi-Fi, Codespaces, and Cloudflare preview hosts when `PUBLIC_BASE_URL` is still localhost. The scanner now accepts links on Socio’s configured QR origin and shows a moving scan line plus a green confirmation animation when it reads a code.
- Improved camera-failure and expired-code guidance, including the phone camera and staff-assisted member pass alternatives.
- Added accessible labels and status announcements to notification controls and live popups; reduced-motion preferences are respected.
- Added a branded loading screen for slower in-app page navigation and form submissions, with a short delay to prevent flicker on fast requests and reduced-motion support.

## Demo limits

- Email remains optional and depends on SMTP configuration. Notification preferences control the Socio inbox, pop-ups, and email independently; no SMS or WhatsApp messages are sent. Pop-ups appear while the member is signed in and using the app; system notifications while the app is closed require a future push-notification service.
- QR attendance is optional per organization. Staff can record eligible active roster members manually when QR check-in is off or unavailable.
- Payments remain simulated. This local/Codespaces demo is not the GCP service or the future Android/iOS apps.

## Updating from Alpha 4

Back up your local demo database before updating. SQLite startup adds the organization QR setting and creates or updates the member notification-preferences table. Existing organizations keep QR check-in enabled to preserve their current behavior; existing members continue to receive inbox updates, pop-ups, and email until they change their preferences. Keep environment files, SMTP credentials, database files, and real personal data out of the GitHub upload.

# Socio v0.1.0-alpha.4

**Prerelease · Local and Codespaces testing build**

Alpha 4 improves the member mobile web experience, especially club update cards and navigation. It builds on Alpha 3 attendance, visit-history, and membership-management flows.

## Changes in Alpha 4

- Fixed club update cards so “Read” and “New” badges stay on one line instead of wrapping into narrow vertical labels.
- Added clear internal padding and improved heading and message spacing on update cards.
- Tuned club names and timestamps to wrap cleanly on narrow screens.
- Improved dark-mode status badge colors for legibility.
- Kept the header theme switch visible and navigation available through a phone-friendly menu.
- Added per-device display preferences: Automatic, Mobile, or Desktop under Settings. Small screens remain responsive even when Desktop is selected.

## Included Alpha 3 capabilities

- Members scan an organization’s QR code when entering and leaving. The home page displays the ongoing club session and a live elapsed timer; completed visits appear in Visit history.
- Members can view simulated membership payment history, request approved tier changes, and manage scheduled cancellation. No real payment is processed.
- Member organization gallery supports cards and compact tabs, with passes, events, and offers.

## Demo limits

- Camera attendance requires browser camera permission and supported devices. Organizations manage their own valid QR codes and attendance policies.
- Payments remain simulated. This is a local/Codespaces demo; GCP hosting and native Android/iOS apps remain future work.

## Updating from Alpha 3

Back up your local demo database before updating. Alpha 4 changes responsive styles and display preferences, and does not require a database migration. Keep `.env`, SMTP credentials, database files, and real personal data out of the GitHub upload.

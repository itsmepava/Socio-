(() => {
  const menu = document.querySelector(".notification-menu");
  if (!menu) return;
  const badge = menu.querySelector("[data-unified-notification-count]");
  const summary = menu.querySelector("summary");
  if (!badge || !summary) return;

  const counts = {
    club: Number(document.body.dataset.clubUnread || 0),
    attendance: Number(document.body.dataset.attendanceUnread || 0),
    messages: Number(document.body.dataset.messageUnread || 0),
  };

  const render = () => {
    const total = Object.values(counts).reduce((sum, value) => sum + Math.max(0, value), 0);
    badge.textContent = total > 99 ? "99+" : String(total);
    badge.hidden = total === 0;
    summary.setAttribute("aria-label", total ? `Notifications, ${total} unread` : "Notifications");
  };

  window.addEventListener("socio:notification-count", (event) => {
    const { source, count } = event.detail || {};
    if (!(source in counts)) return;
    counts[source] = Math.max(0, Number(count) || 0);
    render();
  });

  document.addEventListener("click", (event) => {
    if (!menu.contains(event.target)) menu.open = false;
  });
  render();
})();

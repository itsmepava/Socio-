(() => {
  const clubGrid = document.querySelector("[data-phone-clubs]");
  const viewButtons = Array.from(document.querySelectorAll("[data-phone-club-view]"));
  const viewPreferenceKey = "socio-phone-club-view";

  if (clubGrid && viewButtons.length) {
    let view = "grid";
    try {
      view = localStorage.getItem(viewPreferenceKey) === "list" ? "list" : "grid";
    } catch (error) {
      // Keep the default grid when browser storage is unavailable.
    }

    const setView = (nextView) => {
      view = nextView === "list" ? "list" : "grid";
      clubGrid.dataset.view = view;
      viewButtons.forEach((button) => {
        const selected = button.dataset.phoneClubView === view;
        button.classList.toggle("is-active", selected);
        button.setAttribute("aria-pressed", String(selected));
      });
      try {
        localStorage.setItem(viewPreferenceKey, view);
      } catch (error) {
        // The view switch still works for this page if storage is unavailable.
      }
    };

    viewButtons.forEach((button) => {
      button.addEventListener("click", () => setView(button.dataset.phoneClubView));
    });
    setView(view);
  }

  const search = document.querySelector("[data-phone-pass-search]");
  const passList = document.querySelector("[data-phone-pass-list]");
  if (!search || !passList) return;

  const passCards = Array.from(passList.querySelectorAll("[data-phone-pass-card]"));
  const count = document.querySelector("[data-phone-pass-count]");
  const empty = document.querySelector("[data-phone-pass-empty]");
  const updatePasses = () => {
    const query = search.value.trim().toLocaleLowerCase();
    let visible = 0;
    passCards.forEach((card) => {
      const matches = card.textContent.toLocaleLowerCase().includes(query);
      card.hidden = !matches;
      if (matches) visible += 1;
    });

    if (count) {
      count.textContent = query
        ? `${visible} of ${passCards.length} passes`
        : `${passCards.length} pass${passCards.length === 1 ? "" : "es"}`;
    }
    if (empty) empty.hidden = visible > 0;
  };

  search.addEventListener("input", updatePasses);
  updatePasses();
})();

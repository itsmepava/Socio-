# Socio v0.1.0-alpha.6

Alpha 6 adds private communication and organization-configurable staff attendance details, alongside navigation and layout fixes gathered during Alpha 5 review.

## Included

- Members, organization staff, and platform staff can send private in-app messages and replies through a shared **Messages** inbox.
- SMTP email alerts accompany private messages when SMTP is configured and the recipient has a verified email address. The in-app message is saved even when email delivery is unavailable.
- Club updates and private messages refresh every 15 seconds while their page is visible. New items appear without a page refresh, and pop-ups work independently from inbox and email preferences.
- Reduced unnecessary Codespaces work: organization attendance refreshes every 10 seconds, live polling pauses in hidden tabs and avoids overlapping requests, unread counts are calculated in the database, and attendance elapsed timers still update locally every second.
- Event alerts now show the event poster in the member inbox and live pop-up when one is attached; event emails include the poster inline when SMTP is configured.
- Organization staff can attach an optional poster or image to a club update. It appears in members’ inbox and live pop-up and is embedded in SMTP emails when configured. Image uploads accept PNG, JPEG, or WebP and are normalized before storage.
- The live-update cursor is kept across page navigation in the same browser tab, so updates received while changing pages are not missed.
- Private messages now show live in-app pop-ups and an updating unread count for members, organization staff, and platform staff.
- Organization attendance has a seconds-updating elapsed timer and refreshes check-in/check-out records live; the timer freezes from the saved checkout time after a member leaves.
- Attendance indicators stay green while a visit is active, pulse red for five minutes after checkout, then settle to gray. Reduced-motion settings keep the red status visible without animation.
- Organizations can add up to ten optional or required questions to the staff-assisted attendance form. Answers are saved with the visit and shown in the organization attendance history. QR attendance is unchanged.
- Platform admins with reports access can open a searchable member directory from the dashboard, search by member, email, organization, or tier, and start a support message.
- Platform activity is collapsed by default and searchable when expanded.
- Fixed the member **View club** destination and corrected the visit-history header and buttons.
- Simplified the About page by removing the phone preview and duplicate product explanation.
- Improved the layout of organization transaction summaries and event detail links on narrow screens.
- Updated static asset cache versions so local browsers can receive the Alpha 6 files.

## Local setup notes

- Existing local SQLite databases are updated automatically when Socio starts. Keep a copy of `instance/membership.db` before testing if you need to preserve demo data.
- SMTP settings are optional for testing. Private messages stay available in the in-app inbox if SMTP is not configured.
- Do not put `.env`, SMTP passwords, or secret keys in the repository or release zip.

## Release tag

`v0.1.0-alpha.6`

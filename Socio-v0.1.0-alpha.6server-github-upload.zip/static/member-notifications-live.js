(() => {
  const bell = document.querySelector("[data-notification-bell]");
  const badge = document.querySelector("[data-notification-count]");
  const region = document.querySelector("[data-notification-toast-region]");
  if (!bell || !badge || !region) return;

  const initialCursor = Number(document.body.dataset.notificationLatest || 0);
  const cursorKey = `socio-member-notification-cursor-${document.body.dataset.notificationUser || "current"}`;
  let cursor = initialCursor;
  try {
    const savedValue = window.sessionStorage.getItem(cursorKey);
    const savedCursor = Number(savedValue);
    if (savedValue !== null && Number.isFinite(savedCursor) && savedCursor >= 0) {
      cursor = Math.min(savedCursor, initialCursor);
    } else {
      window.sessionStorage.setItem(cursorKey, String(initialCursor));
    }
  } catch (_) {
    // Notifications still work if browser storage is disabled.
  }
  let polling = false;
  const inbox = document.querySelector("[data-member-notification-list]");
  const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || "";

  const updateUnread = (count) => {
    const value = Math.max(0, Number(count) || 0);
    badge.textContent = value > 99 ? "99+" : String(value);
    badge.hidden = value === 0;
    bell.setAttribute("aria-label", value ? `Club updates, ${value} unread` : "Club updates");
  };

  const showToast = (notification) => {
    const card = document.createElement("article");
    card.className = "notification-toast";
    card.setAttribute("role", "status");
    const heading = document.createElement("div");
    heading.className = "notification-toast-heading";
    const source = document.createElement("span");
    source.className = "eyebrow";
    source.textContent = notification.organization || "Club update";
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "notification-toast-dismiss";
    dismiss.setAttribute("aria-label", "Dismiss club update notification");
    dismiss.textContent = "×";
    dismiss.addEventListener("click", () => card.remove());
    heading.append(source, dismiss);

    const title = document.createElement("strong");
    title.textContent = notification.title || "New club update";
    const body = document.createElement("p");
    body.textContent = notification.body || "A club has shared an update with you.";
    let image = null;
    if (notification.image_url) {
      image = document.createElement("img");
      image.className = "notification-toast-image";
      image.src = notification.image_url;
      image.alt = "Image attached to update from " + (notification.organization || "your club");
      image.loading = "lazy";
    }
    const link = document.createElement("a");
    link.href = "/member/notifications";
    link.textContent = "Open updates →";
    link.addEventListener("click", () => card.remove());
    card.append(heading, title, body);
    if (image) card.append(image);
    card.append(link);
    region.append(card);
    window.setTimeout(() => card.remove(), 15000);
  };

  const updateInbox = (notification) => {
    if (!inbox || !notification.in_app_enabled
        || inbox.querySelector(`[data-notification-id="${Number(notification.id)}"]`)) return;
    document.querySelector("[data-member-notification-empty]")?.remove();
    const card = document.createElement("article");
    card.className = "panel member-notification is-unread";
    card.dataset.notificationId = String(notification.id);
    const header = document.createElement("div");
    header.className = "member-notification-head";
    const details = document.createElement("div");
    const eyebrow = document.createElement("span");
    eyebrow.className = "eyebrow";
    const created = new Date(notification.created_at);
    const dateText = Number.isNaN(created.getTime()) ? "Just now" :
      new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(created);
    eyebrow.textContent = `${notification.organization || "Club update"} · ${dateText}`;
    const title = document.createElement("h2");
    title.textContent = notification.title || "New club update";
    details.append(eyebrow, title);
    const badge = document.createElement("span");
    badge.className = "status-badge status-pending member-notification-status";
    badge.textContent = "New";
    header.append(details, badge);
    const body = document.createElement("p");
    body.textContent = notification.body || "A club has shared an update with you.";
    card.append(header, body);
    if (notification.image_url) {
      const image = document.createElement("img");
      image.className = "member-update-image";
      image.src = notification.image_url;
      image.alt = "Image attached to update from " + (notification.organization || "your club");
      image.loading = "lazy";
      card.append(image);
    }
    if (csrfToken) {
      const form = document.createElement("form");
      form.method = "post";
      form.action = `/member/notifications/${Number(notification.id)}/read`;
      const token = document.createElement("input");
      token.type = "hidden";
      token.name = "csrf_token";
      token.value = csrfToken;
      const button = document.createElement("button");
      button.type = "submit";
      button.className = "button button-quiet button-small";
      button.textContent = "Mark as read";
      form.append(token, button);
      card.append(form);
    }
    inbox.prepend(card);
  };

  const poll = async () => {
    if (polling || document.visibilityState === "hidden") return;
    polling = true;
    try {
      const response = await fetch(`/member/notifications/live?after=${encodeURIComponent(cursor)}`, {
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) return;
      const payload = await response.json();
      cursor = Math.max(cursor, Number(payload.latest_id) || cursor);
      try { window.sessionStorage.setItem(cursorKey, String(cursor)); } catch (_) {}
      updateUnread(payload.unread_count);
      (payload.notifications || []).forEach((notification) => {
        updateInbox(notification);
        if (notification.popup_enabled !== false) showToast(notification);
      });
    } catch (_) {
      // A temporary network interruption should not interrupt the member's current page.
    } finally {
      polling = false;
    }
  };

  // Fetch once when the page opens, then poll often enough that an active
  // member sees club updates promptly. This remains below the route's limit.
  poll();
  window.setInterval(poll, 15000);
  window.addEventListener("focus", poll);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") poll();
  });
})();

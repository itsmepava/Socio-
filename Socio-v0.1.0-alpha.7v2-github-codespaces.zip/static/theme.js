(() => {
  const root = document.documentElement;
  const key = "socio-theme";
  const layoutKey = "socio-display-mode";
  const meta = document.querySelector('meta[name="theme-color"]');

  function applyTheme(theme) {
    root.dataset.theme = theme;
    const nextTheme = theme === "dark" ? "light" : "dark";
    document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
      button.setAttribute("aria-label", `Switch to ${nextTheme} mode`);
      button.setAttribute("title", `Switch to ${nextTheme} mode`);
      const icon = button.querySelector(".theme-icon");
      const label = button.querySelector(".theme-label");
      if (icon) icon.textContent = nextTheme === "dark" ? "☾" : "☀";
      if (label) label.textContent = `${nextTheme[0].toUpperCase()}${nextTheme.slice(1)} mode`;
    });
    if (meta) meta.setAttribute("content", theme === "dark" ? "#111113" : "#f7f5f2");
  }

  let savedTheme = null;
  try {
    savedTheme = localStorage.getItem(key);
  } catch (_) {
    // The theme still works for this page when browser storage is unavailable.
  }
  const initialTheme = savedTheme === "light" || savedTheme === "dark"
    ? savedTheme
    : (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");

  applyTheme(initialTheme);
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const nextTheme = root.dataset.theme === "dark" ? "light" : "dark";
      applyTheme(nextTheme);
      try {
        localStorage.setItem(key, nextTheme);
      } catch (_) {
        // The selected theme remains active until the current page is closed.
      }
    });
  });

  let layoutMode = "auto";
  try {
    const savedLayout = localStorage.getItem(layoutKey);
    if (["auto", "mobile", "desktop"].includes(savedLayout)) layoutMode = savedLayout;
  } catch (_) {
    // Automatic responsive layout remains available without browser storage.
  }

  const applyLayoutMode = (mode) => {
    layoutMode = ["auto", "mobile", "desktop"].includes(mode) ? mode : "auto";
    root.dataset.layoutMode = layoutMode;
    document.querySelectorAll("[data-display-mode]").forEach((radio) => {
      radio.checked = radio.value === layoutMode;
    });
  };
  applyLayoutMode(layoutMode);
  document.querySelectorAll("[data-display-mode]").forEach((radio) => {
    radio.addEventListener("change", () => {
      if (!radio.checked) return;
      applyLayoutMode(radio.value);
      try {
        localStorage.setItem(layoutKey, layoutMode);
      } catch (_) {
        // Keep the choice for the current page if browser storage is unavailable.
      }
      const status = document.querySelector("[data-display-mode-status]");
      if (status) status.textContent = "Display preference saved on this device.";
    });
  });

  const navToggle = document.querySelector("[data-nav-toggle]");
  const nav = document.getElementById("main-navigation");
  if (navToggle && nav) {
    const closeNav = () => {
      nav.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
      navToggle.querySelector(".nav-toggle-icon").textContent = "☰";
      navToggle.querySelector(".nav-toggle-label").textContent = "Menu";
    };
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      navToggle.querySelector(".nav-toggle-icon").textContent = isOpen ? "×" : "☰";
      navToggle.querySelector(".nav-toggle-label").textContent = isOpen ? "Close" : "Menu";
    });
    nav.querySelectorAll("a").forEach((link) => link.addEventListener("click", closeNav));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeNav();
    });
    const desktopViewport = window.matchMedia("(min-width: 1101px)");
    if (desktopViewport.addEventListener) desktopViewport.addEventListener("change", closeNav);
    else if (desktopViewport.addListener) desktopViewport.addListener(closeNav);
  }
})();

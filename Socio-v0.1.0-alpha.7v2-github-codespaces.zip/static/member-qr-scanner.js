(() => {
  const video = document.querySelector('[data-qr-video]');
  const startButton = document.querySelector('[data-qr-start]');
  const stopButton = document.querySelector('[data-qr-stop]');
  const status = document.querySelector('[data-qr-status]');
  const placeholder = document.querySelector('[data-qr-placeholder]');
  const fallback = document.querySelector('[data-qr-fallback]');
  const scannerPanel = document.querySelector('[data-qr-scanner]');
  const purposeSelect = document.querySelector('[data-qr-purpose]');
  const purposeHelp = document.querySelector('[data-qr-purpose-help]');
  const paymentNote = document.querySelector('[data-qr-payment-note]');
  const successNotice = document.querySelector('[data-qr-success]');
  if (!video || !startButton || !stopButton || !status) return;

  let stream;
  let scanning = false;
  let detector;
  let lastUnrecognizedNotice = 0;

  const setStatus = (message) => { status.textContent = message; };
  const updatePurposeHelp = () => {
    const isPayment = purposeSelect?.value === 'booking_payment';
    if (purposeHelp) purposeHelp.textContent = isPayment
      ? 'Use this only to pay a facility booking fee. You will review the booking and amount before confirming.'
      : purposeSelect?.value === 'booking_checkin'
        ? 'Use this when arriving for or leaving an approved facility booking. Payment is handled separately.'
        : 'Use this when arriving at or leaving a club. Your visit is only recorded after you review and confirm.';
    if (paymentNote) paymentNote.hidden = !isPayment;
  };
  purposeSelect?.addEventListener('change', updatePurposeHelp);
  updatePurposeHelp();
  const stop = () => {
    scanning = false;
    scannerPanel?.classList.remove('is-scanning');
    if (stream) stream.getTracks().forEach((track) => track.stop());
    stream = undefined;
    video.srcObject = null;
    startButton.disabled = false;
    stopButton.disabled = true;
    placeholder.hidden = false;
  };

  const findSocioCheckin = (rawValue) => {
    try {
      const url = new URL(rawValue, window.location.origin);
      const configuredOrigin = scannerPanel?.dataset.qrOrigin;
      if (url.origin !== window.location.origin && url.origin !== configuredOrigin) return null;
      const match = url.pathname.match(/^\/check-in\/club\/([A-Za-z0-9_-]{20,160})\/?$/);
      if (!match) return null;
      const purpose = ['attendance', 'booking_checkin', 'booking_payment'].includes(purposeSelect?.value)
        ? purposeSelect.value : 'attendance';
      return `/check-in/club/${match[1]}?purpose=${purpose}`;
    } catch (_) {
      return null;
    }
  };

  const scanFrame = async () => {
    if (!scanning) return;
    try {
      const codes = await detector.detect(video);
      const target = codes.map((code) => findSocioCheckin(code.rawValue)).find(Boolean);
      if (target) {
        scanning = false;
        scannerPanel?.classList.add('is-detected');
        if (successNotice) successNotice.hidden = false;
        setStatus('QR code found. Opening your check-in…');
        stop();
        if (navigator.vibrate) navigator.vibrate(35);
        window.setTimeout(() => window.location.assign(target), 720);
        return;
      }
      if (codes.length && Date.now() - lastUnrecognizedNotice > 4000) {
        lastUnrecognizedNotice = Date.now();
        setStatus('QR detected, but it is not a Socio club check-in code. Scan the current code displayed by your organization.');
      }
    } catch (_) {
      // Frames can be temporarily unreadable while the camera adjusts.
    }
    if (scanning) window.requestAnimationFrame(scanFrame);
  };

  startButton.addEventListener('click', async () => {
    fallback.hidden = true;
    if (successNotice) successNotice.hidden = true;
    scannerPanel?.classList.remove('is-detected');
    if (!('BarcodeDetector' in window) || !navigator.mediaDevices?.getUserMedia) {
      setStatus('This browser does not provide in-page QR scanning. Use your phone camera app to scan the organization code.');
      fallback.hidden = false;
      return;
    }
    try {
      detector = new window.BarcodeDetector({ formats: ['qr_code'] });
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      video.srcObject = stream;
      await video.play();
      scanning = true;
      scannerPanel?.classList.add('is-scanning');
      startButton.disabled = true;
      stopButton.disabled = false;
      placeholder.hidden = true;
      setStatus('Point your camera at the organization’s QR code.');
      window.requestAnimationFrame(scanFrame);
    } catch (_) {
      stop();
      setStatus('Camera access was unavailable. Allow camera permission or use another check-in method below.');
      fallback.hidden = false;
    }
  });

  stopButton.addEventListener('click', () => {
    stop();
    setStatus('The camera is off.');
  });
  window.addEventListener('pagehide', stop);
})();

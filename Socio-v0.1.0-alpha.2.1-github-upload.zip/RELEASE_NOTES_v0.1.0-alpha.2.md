# Socio v0.1.0-alpha.2

This alpha builds on the fresh-repository alpha 1 demo and adds member account quality-of-life and financial record workflows.

## Added

- Members can update their profile name, optional phone number and gender, and profile photo.
- The member club gallery shows each club’s membership tier and marks the highest priced available tier as the club’s top tier.
- Members can view their per-club membership payment records and submit bill or expense details with a receipt photo.
- Organization admins with member-management access can review or decline submitted bill and expense proofs. Members receive an in-app notification with the result.
- Members can request upgrades or downgrades to an organization’s configured membership tiers, with an optional note. Organizations review and approve or decline the request.
- Approved tier changes proceed through simulated checkout before taking effect. Upgrades use a prorated amount; downgrades show no extra amount due during the current paid period.
- Organizations can set a price and monthly or yearly billing period for each tier, and view a transaction ledger scoped to their own club.
- The simulated checkout includes sample card fields with browser-side checks. Card details are never sent to the server or saved; no real payment is made.
- Local startup can add four more fictional organizations, sample member logins, club events and offers, in-app updates, and transaction examples. These fixtures are restricted to local SQLite with localhost or private Wi-Fi URLs.
- Members can switch their gallery between the full card grid and a compact organization-tab view; the selected layout is remembered in that browser.
- The mobile app concept shows club memberships as a compact icon grid inside a fixed-size phone frame, with the screen scrolling internally when a member has many clubs.

## Important demo limits

- Membership payment history contains only transactions Socio records; offline payments need to be entered by the organization to appear there.
- Receipt acceptance records an organization’s review. Socio does not validate whether money changed hands or reimburse expenses.
- A top-tier badge is based on the highest priced active plan configured by that organization. It is a display label, not a judgment of a member’s status or spending.
- This remains a local alpha for team review, not a public production service.

## Upgrade from alpha 1

The app creates new tables and adds the member profile columns when it starts against its local SQLite database. Keep a backup of any demo database before upgrading. Do not include `.env`, SMTP credentials, or a real card number in a GitHub upload.

(() => {
  const search = document.querySelector("[data-member-search]");
  const select = document.querySelector("[data-member-select]");
  if (!search || !select) return;

  const members = Array.from(select.options).slice(1).map((option) => ({
    option,
    text: `${option.textContent || ""} ${option.dataset.memberSearchValue || ""}`.toLocaleLowerCase()
  }));
  search.addEventListener("input", () => {
    const query = search.value.trim().toLocaleLowerCase();
    for (const member of members) {
      member.option.hidden = Boolean(query) && !member.text.includes(query);
    }
    if (select.selectedOptions[0]?.hidden) select.value = "";
  });
})();

(() => {
  const bell = document.querySelector("[data-organization-notification-bell]");
  const region = document.querySelector("[data-organization-toast-region]");
  if (!bell || !region) return;

  let latestId = Number(document.body.dataset.organizationNotificationLatest || 0);
  const count = bell.querySelector("[data-organization-notification-count]");
  const inboxUrl = "/organization/notifications";

  function toast(item) {
    const card = document.createElement("article");
    card.className = "notification-toast organization-notification-toast";
    card.setAttribute("role", "status");
    const heading = document.createElement("div");
    heading.className = "notification-toast-heading";
    const label = document.createElement("span");
    label.className = "eyebrow";
    label.textContent = item.event_type === "check_in" ? "Member checked in" : "Member checked out";
    if (item.manual_entry) label.textContent += " · Staff recorded";
    const dismiss = document.createElement("button");
    dismiss.className = "notification-toast-dismiss";
    dismiss.type = "button";
    dismiss.setAttribute("aria-label", "Dismiss attendance alert");
    dismiss.textContent = "×";
    dismiss.addEventListener("click", () => card.remove());
    heading.append(label, dismiss);
    const title = document.createElement("strong");
    title.textContent = item.member || "Member attendance updated";
    const body = document.createElement("p");
    body.textContent = `${item.organization} · ${item.tier}${item.manual_entry ? " · Recorded manually" : ""}`;
    const link = document.createElement("a");
    link.href = inboxUrl;
    link.textContent = "View attendance alerts";
    card.append(heading, title, body, link);
    region.append(card);
    window.setTimeout(() => card.remove(), 10000);
  }

  function setUnread(value) {
    const unread = Math.max(0, Number(value) || 0);
    if (count) {
      count.textContent = unread > 99 ? "99+" : String(unread);
      count.hidden = unread === 0;
    }
    bell.setAttribute("aria-label", `Attendance alerts${unread ? `, ${unread} unread` : ""}`);
  }

  async function poll() {
    try {
      const response = await fetch(`/organization/notifications/live?after=${latestId}`, {
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        cache: "no-store"
      });
      if (!response.ok) return;
      const data = await response.json();
      for (const item of data.notifications || []) {
        latestId = Math.max(latestId, Number(item.id) || 0);
        toast(item);
      }
      latestId = Math.max(latestId, Number(data.latest_id) || 0);
      setUnread(data.unread_count);
    } catch (_) {
      // Keep the current count and retry on the next interval.
    }
  }

  window.setInterval(poll, 15000);
})();

(() => {
  const clocks = [...document.querySelectorAll('[data-visit-clock][data-visit-elapsed]')];
  if (!clocks.length) return;
  const monotonicStart = performance.now();
  const update = () => {
    const elapsedSinceRender = Math.floor((performance.now() - monotonicStart) / 1000);
    clocks.forEach((clock) => {
      const elapsedAtRender = Number.parseInt(clock.dataset.visitElapsed, 10);
      if (!Number.isFinite(elapsedAtRender)) return;
      const elapsed = Math.max(0, elapsedAtRender + elapsedSinceRender);
      const hours = Math.floor(elapsed / 3600);
      const minutes = Math.floor((elapsed % 3600) / 60);
      const seconds = elapsed % 60;
      clock.textContent = hours
        ? `${hours}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`
        : `${minutes}m ${String(seconds).padStart(2, '0')}s`;
      clock.setAttribute('aria-label', `${hours} hours, ${minutes} minutes, ${seconds} seconds at the club`);
    });
  };
  update();
  window.setInterval(update, 1000);
})();

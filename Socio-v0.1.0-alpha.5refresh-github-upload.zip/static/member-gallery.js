(() => {
  const gallery = document.querySelector("[data-member-gallery]");
  if (!gallery) return;

  const tabs = document.querySelector("[data-gallery-tabs]");
  const hint = document.querySelector("[data-gallery-hint]");
  const cards = Array.from(gallery.querySelectorAll("[data-gallery-card]"));
  const tabButtons = Array.from(document.querySelectorAll("[data-gallery-tab]"));
  const modeButtons = Array.from(document.querySelectorAll("[data-gallery-mode-button]"));
  const preferenceKey = "socio-member-gallery-mode";
  let mode = "cards";
  let activeOrganization = null;

  try {
    mode = window.localStorage.getItem(preferenceKey) === "tabs" ? "tabs" : "cards";
  } catch (_) {
    // Keep the gallery usable when browser storage is disabled.
  }

  const selectOrganization = (organizationId, focusTab = false) => {
    activeOrganization = String(organizationId);
    tabButtons.forEach((button) => {
      const selected = button.dataset.galleryTab === activeOrganization;
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
      if (selected && focusTab) button.focus();
    });
    cards.forEach((card) => {
      const selected = card.dataset.galleryCard === activeOrganization;
      card.hidden = mode === "tabs" && !selected;
      if (mode === "tabs") {
        card.setAttribute("role", "tabpanel");
        card.setAttribute("aria-labelledby", `club-tab-${card.dataset.galleryCard}`);
      }
    });
    if (hint) hint.hidden = mode !== "tabs" || Boolean(activeOrganization);
  };

  const setMode = (nextMode) => {
    mode = nextMode === "tabs" ? "tabs" : "cards";
    const compact = mode === "tabs";
    gallery.classList.toggle("gallery-grid-compact", compact);
    if (tabs) tabs.hidden = !compact;
    modeButtons.forEach((button) => {
      const selected = button.dataset.galleryModeButton === mode;
      button.classList.toggle("is-active", selected);
      button.setAttribute("aria-pressed", String(selected));
    });

    if (compact) {
      activeOrganization = null;
      cards.forEach((card) => {
        card.hidden = true;
        card.setAttribute("role", "tabpanel");
        card.setAttribute("aria-labelledby", `club-tab-${card.dataset.galleryCard}`);
      });
      tabButtons.forEach((button, index) => {
        button.setAttribute("aria-selected", "false");
        button.tabIndex = index === 0 ? 0 : -1;
      });
      if (hint) hint.hidden = false;
    } else {
      cards.forEach((card) => {
        card.hidden = false;
        card.removeAttribute("role");
        card.removeAttribute("aria-labelledby");
      });
      tabButtons.forEach((button) => {
        button.setAttribute("aria-selected", "false");
        button.tabIndex = -1;
      });
      if (hint) hint.hidden = true;
    }

    try {
      window.localStorage.setItem(preferenceKey, mode);
    } catch (_) {
      // A preference is optional; the current view remains functional.
    }
  };

  modeButtons.forEach((button) => {
    button.addEventListener("click", () => setMode(button.dataset.galleryModeButton));
  });
  tabButtons.forEach((button, index) => {
    button.addEventListener("click", () => {
      selectOrganization(button.dataset.galleryTab);
    });
    button.addEventListener("keydown", (event) => {
      let nextIndex = index;
      if (event.key === "ArrowRight") nextIndex = (index + 1) % tabButtons.length;
      else if (event.key === "ArrowLeft") nextIndex = (index - 1 + tabButtons.length) % tabButtons.length;
      else if (event.key === "Home") nextIndex = 0;
      else if (event.key === "End") nextIndex = tabButtons.length - 1;
      else return;
      event.preventDefault();
      selectOrganization(tabButtons[nextIndex].dataset.galleryTab, true);
    });
  });

  setMode(mode);
})();

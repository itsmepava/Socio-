(() => {
  const overlay = document.querySelector("[data-page-loading]");
  if (!overlay) return;

  let showTimer = 0;

  const reveal = () => {
    window.clearTimeout(showTimer);
    showTimer = 0;
    overlay.hidden = false;
    overlay.setAttribute("aria-hidden", "false");
    document.documentElement.classList.add("is-page-loading");
    const main = document.querySelector("#main-content");
    if (main) main.setAttribute("aria-busy", "true");
  };

  const schedule = () => {
    if (overlay.hidden && !showTimer) {
      // Avoid flashing the loading card during quick local page changes.
      showTimer = window.setTimeout(reveal, 140);
    }
  };

  const isPlainPrimaryClick = (event) => event.button === 0
    && !event.defaultPrevented
    && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey;

  document.addEventListener("click", (event) => {
    if (!isPlainPrimaryClick(event)) return;
    const targetElement = event.target instanceof Element ? event.target : event.target?.parentElement;
    const link = targetElement?.closest("a[href]");
    if (!link || link.hasAttribute("download") || link.dataset.noLoading !== undefined) return;
    if (link.target && link.target.toLowerCase() !== "_self") return;

    let destination;
    try {
      destination = new URL(link.href, window.location.href);
    } catch (_) {
      return;
    }
    if (destination.origin !== window.location.origin) return;
    if (destination.pathname === window.location.pathname
        && destination.search === window.location.search
        && destination.hash) return;
    if (destination.href === window.location.href) return;
    schedule();
  });

  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.dataset.noLoading !== undefined) return;
    const submitterTarget = event.submitter?.formTarget;
    const target = submitterTarget || form.target;
    if (target && target.toLowerCase() !== "_self") return;
    if ((form.method || "get").toLowerCase() === "dialog") return;
    try {
      const action = new URL(form.action || window.location.href, window.location.href);
      if (action.origin === window.location.origin) schedule();
    } catch (_) {
      // Leave the page unchanged when a form has an invalid action.
    }
  });

  window.addEventListener("pageshow", () => {
    window.clearTimeout(showTimer);
    showTimer = 0;
    overlay.hidden = true;
    overlay.setAttribute("aria-hidden", "true");
    document.documentElement.classList.remove("is-page-loading");
    const main = document.querySelector("#main-content");
    if (main) main.removeAttribute("aria-busy");
  });

  window.SocioPageLoading = { show: schedule };
})();

(() => {
  const formatters = {
    date: new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }),
    time: new Intl.DateTimeFormat(undefined, { timeStyle: "short" }),
    full: new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }),
  };

  document.querySelectorAll("time[data-local-time][datetime]").forEach((element) => {
    const date = new Date(element.dateTime);
    if (Number.isNaN(date.getTime())) return;
    const format = element.dataset.localFormat || "full";
    element.textContent = (formatters[format] || formatters.full).format(date);
    element.title = `Your local time (${Intl.DateTimeFormat().resolvedOptions().timeZone})`;
  });
})();

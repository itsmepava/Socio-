# Socio v0.1.0-alpha.3

**Prerelease · Local and Codespaces testing build**

Alpha 3 adds a more complete club attendance flow and member expense rewards. It is intended for team review and demo use.

## Highlights

- **Club QR attendance:** Members scan an organization’s rotating QR code when they arrive and scan again when they leave. After check-in, Socio sends the member to their home page and shows the current club session. After checkout, a success message thanks the member, reports the visit duration, and confirms that the visit was added to history.
- **Member Visit history:** A new member tab shows active visits and completed visits across clubs, including membership tier, visit date, arrival, departure, and total duration.
- **Local visit times:** Visit timestamps are stored in UTC for consistent records and displayed in the viewer’s device timezone.
- **Current ongoing session:** The member home page displays the club, membership tier, arrival time, and a live elapsed timer. The active session appears above the welcome banner and club gallery. It starts from server-calculated elapsed time and continues with a monotonic browser clock, so phone clock or timezone differences do not distort the displayed duration.
- **Visit confirmation:** After a member scans to leave, the most recent completed visit appears on the member home page with its duration and local arrival/departure times. A **Close** button dismisses that confirmation while keeping the visit in history.
- **Expense reward draws:** Organizations can create an optional expense reward draw with a prize, terms, deadline, and winner count. Members can opt a club expense into a draw. The organization reviews the receipt, closes entries, selects winners manually, and arranges the prize.
- **Sample bill uploads:** Members can mark uploaded images as sample/test evidence, so teams can try bill review and reward-draw workflows without real club receipts. The label is visible in member history, organization review, and draw entries. Sample files must not be treated as proof of a real expense or used to award a real prize.
- **Member gallery:** Members can continue using the full gallery or compact tab view to find their clubs, membership passes, offers, events, and billing details.

## Demo limits

- Attendance needs camera permission and browser support. If the in-app camera scanner is unavailable, the phone camera can open the club QR link.
- Socio records visit times; organizations are responsible for displaying valid club QR codes and managing attendance policies.
- Expense proof review does not verify a bank transfer or issue reimbursement. Only accepted expense proofs qualify for reward draws.
- Sample/test uploads are demo evidence only. Organizations should not accept them as real expenses or select them for real-world rewards.
- Reward draws are managed by the organization. Socio does not randomly select winners, verify prize fulfillment, or distribute prizes.
- Payments remain simulated. No real payment is collected or processed.
- This is a local/Codespaces demo, not a production consumer service. GCP hosting and native Android/iOS apps remain future work.

## Updating from Alpha 2

Back up your local demo database before starting Alpha 3. The app creates newly required tables and adds the attendance departure timestamp to an existing SQLite database during startup. Keep `.env`, SMTP credentials, database files, and real personal data out of the GitHub upload.
